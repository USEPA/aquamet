# constructImageLocation.r
#
# 11/09/10 ssr Created.
#

  # Create formimage location if images exist

constructImageLocation <- function (df, meta.df, siteInfo
         , infoKeys=c('SITE_ID','DATE_COL','VISIT_NO'), ssFmt='EXCEL')

# Returns constructed dataframe with the following columns: SITE_ID, VISIT_NO,
# DATE_COL, TRANSECT, PARAMETER, TESTDESCRIPTION, RESULT, UNITS (if present
# in df), FORMIMAGE, COMMENTS.
#
# POSSIBLE FUTURE EXTENSIONS:
# + Handling fish related form images, which have _P1, _P2, etc. at end of
#   the file name.  There is also the Lower Missisippi form which may have these
#   extensions.
#
# ARGUMENTS:
# df            data frame of validation results.  Is expected to have the
#                 columns expected for NRSA validation results, and will
#                 specifically use UID, TRANSECT, PARAMETER, TESTDESCRIPTION,
#                 RESULT, UNITS (if present) and TESTDESCRIPTION.

# siteInfo      dataframe with information relating the UID of a table to the
#                 relevant site information.  Contains columns UID, SITE_ID,
#                 and VISIT_NO.

# infoKeys      relevant columns in siteInfo

  {
  probs <- NULL
  tableKeys <- names(df)[names(df) %in% NRSAKeyColumns & names(df) != 'UID']
  
  if (imageExists==TRUE){
  
  # Make sure that siteInfo contains the appropriate columns
  if('FORMABBR' %nin% names(meta.df)) {
      probs<-"Error: FORMABBR not a column in meta.df"
      return(as.matrix(probs))
  }

  if(all(infoKeys %nin% names(siteInfo))) {
      probs<-"Error: not all infoKeys not are columns in siteInfo"
      return(as.matrix(probs))
  }
  
    
  aa <- subset(df, select=c('UID',tableKeys,'PARAMETER','UNITS'))
  bb <- subset(meta.df, select=c('FORMABBR','SAMPLE_TYPE','PARAMETER','UNITS'))
  cc <- subset(siteInfo, select=c('UID',infoKeys))

  dd <- merge(aa, bb)
  df <- merge(dd, cc)
  

  df$ffName <- ifelse(df$FORMABBR %in% c('ChRip', 'Thal')
                     # The value of TRANSECT is a part of these form file names
                     ,ifelse(df$FORMABBR=='ChRip' &
                             format(as.POSIXct(df$DATE_COL), '%Y')> 2008 &
                             df$SAMPLE_TYPE %in% c('PHAB_CHANB','PHAB_CHANBFRONT')
                            # Both sides of the boatable form of ChRip were
                            # exported as a single TIFF in 2008, but as separate
                            # files in 2009 because of scanner troubles.  Use
                            # PARAMETER to determine which file to hyperlink to.
                           ,paste('NRSA'
                                 ,df$FORMABBR
                                 ,df$SITE_ID
                                 ,paste('V', df$VISIT_NO, sep='')
                                 ,df$TRANSECT
                                 ,ifelse(df$PARAMETER %in% parametersChRip_p2
                                        ,'P2'
                                        ,'P1'
                                        )
                                 ,sep='_'
                                 )
                         # Otherwise just include transect without any page num.
                           ,paste('NRSA'
                                 ,df$FORMABBR
                                 ,df$SITE_ID
                                 ,paste('V', df$VISIT_NO, sep='')
                                 ,df$TRANSECT
                                 ,sep='_'
                                 )
                           )
                     # Other forms do not contain transect in their file names
                     ,paste('NRSA'
                           ,df$FORMABBR
                           ,df$SITE_ID
                           ,paste('V', df$VISIT_NO, sep='')
                           ,sep='_'
                           )
                     )

  df$ffName <- paste('L:/Apps/Scantron/Images/'
                    ,format(as.POSIXct(df$DATE_COL), '%Y')
                    ,'/Flowing Waters/'
                    ,df$ffName
                    ,'.tif'
                    , sep=''
                    )


  # Write field form file name as URL.  This is spreadsheet dependent.
  #   Microsoft Excel: =HYPERLINK("file:/path/fname.tif", "optional label")
  #                    Note there can be 1-3 slashes after the 'file:', but
  #                    double-quotes are required.
  #   OpenOffice Calc: =HYPERLINK('file:///path/fname.tif'; 'optional label')
  #                    Note that 1 or 3 slashes are required after the file:
  #                    and the semicolon is required to delimit the arguments,
  #                    as is the use of double-quotes.
  #   Gnu Gnumeric:    =HYPERLINK() does not work, may be fixed soon. feh.
  if(ssFmt=='OO') {
      df$FORMIMAGE <- paste('=HYPERLINK("file:///'
                           ,df$ffName, '" ; "', df$FORMABBR
                           ,'")'
                           ,sep=''
                           )
  } else if(ssFmt=='EXCEL') {
      df$FORMIMAGE <- paste('=HYPERLINK("file:///'
                           ,df$ffName, '" , "', df$FORMABBR
                           ,'")'
                           ,sep=''
                           )
  }
  intermediateMessage('.1')

#  df <- subset(df, select=c('UID', infoKeys, 'FORMIMAGE'))
  df <- subset(df, select=c('UID',infoKeys,tableKeys,'PARAMETER','FORMIMAGE'))
                         }

  if (imageExists==FALSE){
  df <- NULL
                           }
  return(df)
  }