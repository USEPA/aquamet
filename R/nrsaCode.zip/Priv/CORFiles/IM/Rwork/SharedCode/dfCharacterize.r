# dfCharacterize.r
#
#  7/12/10 cws created
#
require(RUnit)

dfCharacterize <- function(df, maxTableSize=10)
# Characterizes a dataframe, providing a bit more information than str(),
# characterizing the distribution of numeric values as well as some info
# on character data. There is no return value.
#
# ARGUMENTS:
# df            the data.frame to scrutinize in mild detail
# maxTableSize  an integer specifying the maximum number of distinct values
#               the data can have to be characterized with a table object.
#               Data with more distinct values than this limit will not
#               be characterized by table().
{
  cc <- dfCharacterize.create(df, maxTableSize)
  rr <- dfCharacterize.print(cc)

}

dfCharacterize.create <- function(df, maxTableSize)
# Characterizes a dataframe, returning a list of characterizations for
# each column in the dataframe.
#
# ARGUMENTS:
# df            the data.frame to scrutinize in mild detail
# maxTableSize  an integer specifying the maximum number of distinct values
#               the data can have to be characterized with a table object.
#               Data with more distinct values than this limit will not
#               be characterized by table().
{
  ll<- list()
  for(c in 1:ncol(df)) {
      cname <- names(df)[c]
      colClass <- class(df[,cname])
      if(all(colClass == c("POSIXt", "POSIXct"))) colClass <- 'POSIXt'

      if (all(is.na(df[,cname]))) {
          # Handle case of all missing values here to simplify the rest of
          # the code.
          ll[[cname]] <- list(class=colClass
                             ,allMissing=TRUE
                             )
      } else if (colClass == 'character') {
          ss <- sort(df[,cname])
          ll[[cname]] <- list(class=colClass
                             ,minLength = min(nchar(df[,cname]), na.rm=TRUE)
                             ,maxLength = max(nchar(df[,cname]), na.rm=TRUE)
                             ,first = ss[1]
                             ,last = ss[length(ss)]
                             ,nMissing = sum(is.na(df[,cname]), na.rm=TRUE)
                             ,nDistinct = length(unique(df[,cname]))
                             )
      } else if (colClass == 'factor') {
          # convert all factors to character class for printing.
          cc <- as.character(df[,cname])
          ss <- sort(cc)
          ll[[cname]] <- list(class=colClass
                             ,minLength = min(nchar(ss), na.rm=TRUE)
                             ,maxLength = max(nchar(ss), na.rm=TRUE)
                             ,first = ss[1]
                             ,last = ss[length(ss)]
                             ,nLevels = length(levels(df[,cname]))
                             ,nMissing = sum(is.na(cc), na.rm=TRUE)
                             ,nDistinct = length(unique(cc))
                             )
      } else if (colClass %in% c('integer','numeric')) {
          ll[[cname]] <- list(class=colClass
                             ,min = min(df[,cname], na.rm=TRUE)
                             ,max = max(df[,cname], na.rm=TRUE)
                             ,mean = mean(df[,cname], na.rm=TRUE)
                             ,stdev = sd(df[,cname], na.rm=TRUE)
                             ,nMissing = sum(is.na(df[,cname]), na.rm=TRUE)
                             ,nNaN = sum(is.nan(df[,cname]), na.rm=TRUE)
                             ,nDistinct = length(unique(df[,cname]))
                             )
      } else if (colClass == 'logical') {
          ll[[cname]] <- list(class=colClass
                             ,nTrue = sum(df[,cname]==TRUE, na.rm=TRUE)
                             ,nFalse = sum(df[,cname]==FALSE, na.rm=TRUE)
                             ,nMissing = sum(is.na(df[,cname]), na.rm=TRUE)
                             ,nDistinct = length(unique(df[,cname]))
                             )
      } else if (colClass == 'POSIXt') {
          ss <- sort(df[,cname])
          ll[[cname]] <- list(class=colClass
                             ,min = min(df[,cname], na.rm=TRUE)
                             ,max = max(df[,cname], na.rm=TRUE)
                             ,nMissing = sum(is.na(df[,cname]), na.rm=TRUE)
                             ,nNaN = sum(is.nan(df[,cname]), na.rm=TRUE)
                             ,nDistinct = length(unique(df[,cname]))
                             )

      } else {
          print(sprintf("Column %s is unknown class <%s>", cname, colClass))
          ll[[cname]] <- list(class=colClass
                             ,allMissing=TRUE
                             )
      }
      
      if (!all(is.na(df[[cname]]))) {
          if(ll[[cname]]$nDistinct <= maxTableSize) {
              ll[[cname]]$table <- table(df[,cname], useNA='ifany')
          }
      }
      
  }

  return(ll)
}


dfCharacterize.print <- function(characterization)
# Prints the list created by dfCharacterize.create()
#
# ARGUMENTS:
# characterization  a list, as returned from dfCharacterize.create().
#
{
  op <- options(digits.secs=3)

  for(i in 1:length(characterization)) {
      itemName <- names(characterization)[i]
      itemClass <- characterization[[i]]$class
      item <- characterization[[itemName]]

      cat(sprintf("%s (%s)\n", itemName, itemClass))
      if (!is.null(item$allMissing)) {
          cat("  All values are NA.\n")
      } else if (itemClass=='character') {
          cat(sprintf("  first     = %-22s     last       = %-22s\n"
                     ,paste("<", substr(item$first,1,20), ">", sep='')
                     ,paste("<", substr(item$last,1,20), ">", sep='')
                     )
               )
          cat(sprintf("  shortest  = %-10i                 longest    = %-10i characters\n"
                     ,item$minLength, item$maxLength
                     )
               )
          cat(sprintf("  # missing = %-10i                 # distinct = %-10i\n"
                     ,item$nMissing, item$nDistinct
                     )
               )
      } else if (itemClass == 'integer') {
          cat(sprintf("  min        =    %-10i             max        =    %10i\n"
                     ,item$min, item$max
                     )
               )
          cat(sprintf("  mean       = %-20f      stdev      = %20f\n"
                     ,item$mean, item$stdev
                     )
               )
          cat(sprintf("  # missing  =    %-10i             # distinct =    %10i\n"
                     ,item$nMissing, item$nDistinct
                     )
               )
          cat(sprintf("  # NaN      =    %-10i\n"
                     ,item$nNaN
                     )
               )
      } else if (itemClass == 'numeric') {
          cat(sprintf("  min        = %20f      max        = %20f\n"
                     ,item$min, item$max
                     )
               )
          cat(sprintf("  mean       = %20f      stdev      = %20f\n"
                     ,item$mean, item$stdev
                     )
               )
          cat(sprintf("  # missing  =    %10i             # distinct =    %10i\n"
                     ,item$nMissing, item$nDistinct
                     )
               )
          cat(sprintf("  # NaN      =    %10i\n"
                     ,item$nNaN
                     )
               )
      } else if (itemClass == 'logical') {
          cat(sprintf("  # TRUE     = %20f      # FALSE    = %20f\n"
                     ,item$nTrue, item$nFALSE
                     )
               )
          cat(sprintf("  # missing  =    %-10i\n"
                     ,item$nMissing
                     )
               )

      } else if (itemClass == 'POSIXt') {
          cat(sprintf("  min        = %-23s   max        = %-23s\n"
                     ,item$min, item$max
                     )
               )
          cat(sprintf("  # missing  =    %10i             # distinct =    %10i\n"
                     ,item$nMissing, item$nDistinct
                     )
               )
          cat(sprintf("  # NaN      =    %10i\n"
                     ,item$nNaN
                     )
               )

      } else {
          print(sprintf("item %s is unknown class <%s>", itemName, itemClass))
      }
      
      if(is.null(item$allMissing)) {
          if(!is.null(item$table) & item$nDistinct > 1) {
              print(item$table)
          }
      }
      
      cat('\n')
   }
  
   options(op)
}


dfCharacterize.createTest <- function()
# Unit test for dfCharacterize.create()
{
  # create test dataframe with columns of many different classes
  df <- data.frame(a=as.double(seq(0,5, length.out=10))
                  ,b=as.single(seq(0,5, length.out=10))
                  ,c=as.integer(1:10)
                  ,d=as.character(1:10)           # convert to character
                  ,e=as.character(1:10)           # leave as factor
                  ,f=as.logical(c(0,1,0,1,0,1,0,1,1,1))
                  ,g=NA
                  ,h=NaN
                  )
  df$d <- as.character(df$d)

  # Expected results
  ee <- list(a=list(class='numeric', min=0, max=5
                   ,mean=2.5, stdev=1.682027974498607
                   ,nMissing=0L, nNaN=0L, nDistinct=10L
                   ,table=table( as.double(seq(0,5, length.out=10)) )
                   )
            ,b=list(class='numeric', min=0, max=5
                   ,mean=2.5, stdev=1.682027974498607
                   ,nMissing=0L, nNaN=0L, nDistinct=10L
                   ,table=table( as.double(seq(0,5, length.out=10)) )
                   )
            ,c=list(class='integer', min=1L, max=10L
                   ,mean=5.5, stdev=3.027650354097492
                   ,nMissing=0L, nNaN=0L, nDistinct=10L
                   ,table=table( as.integer(1:10) )
                   )
            ,d=list(class='character', minLength=1L, maxLength=2L
                   ,first='1', last='9'
                   ,nMissing=0L, nDistinct=10L
                   ,table=table( as.character(1:10) )
                   )
            ,e=list(class='factor', minLength=1L, maxLength=2L
                   ,first='1', last='9', nLevels=10L
                   ,nMissing=0L, nDistinct=10L
                   ,table=table( as.character(1:10) )
                   )
            ,f=list(class='logical'
                   ,nTrue=6L, nFalse=4L
                   ,nMissing=0L, nDistinct=2L
                   ,table=table( as.logical(c(0,1,0,1,0,1,0,1,1,1)) )
                   )
            ,g=list(class='logical', allMissing=TRUE
                   )
            ,h=list(class='numeric', allMissing=TRUE
                   )
            )

  # check accuracy of characterization
  rr <- dfCharacterize.create(df, 10)
  
  checkEquals(ee[[5]], rr[[5]], "Error: dataframe mischaracterized")
  
}
# end of file