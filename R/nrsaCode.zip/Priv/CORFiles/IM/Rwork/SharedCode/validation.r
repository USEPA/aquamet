# validation.r
#
# Sources functions used in the validation of dataframes.
#
# 09/22/09 cws Created
# 10/28/09 cws Updated with more shared validation file
# 06/01/10 cws included stValNonNumericValues.r
# 12/05/11 cws Deprecating dbReachTable.

require(RUnit)

# structure checking functions
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValAbsentValues.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValColumnPresence.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValCountRows.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValMissingValues.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValUnexpectedValues.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/stValNonNumericValues.r')

# other validation functions
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/validationLegal.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/validationMissing.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/validationRange.r')

# miscellaneous support functions
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/printTimingInfo.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/testSuiteValidation.r')

# end of file


