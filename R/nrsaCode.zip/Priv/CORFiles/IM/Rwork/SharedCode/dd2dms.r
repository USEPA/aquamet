# dd2dms.r
#
# 08/27/2010 cws created
# 09/23/2010 cws rewrote to handle floating point rounding error and handling NA
#            values and negative values.  Added unit test.
# 01/17/2012 cws removed text value input in unit test to avoid warning message
#            about NAs introduced by coercion.  The remaining NA will show how it
#            handles NA inputs.

require(RUnit)

dd2dms <- function(x)
# convert dd coordinate pair to dms string.  Rounding to 7 digits after the
# decimal point is done to prohibit errors due to floating point representation.
#
# Note: attempt to convert text that can not be coerced into a numeric type
# will cause generation of warning messages that NAs were introduced by
# coercion.
#
# ARGUMENTS:
# dd       numeric value of angle in decimal degrees
{
   dd <- as.numeric(x)
   d  <- trunc(dd)
   ms <- abs(round(dd-d, 7))
   m  <- trunc(ms*60)
   t  <- round(ms-m/60, 7)
   s  <- round(t*3600, 1)
   
   r <- ifelse(is.na(dd)
              ,NA
              ,sprintf("%02d:%02d:%04.1f", d, m, s)
              )
   return(r)
#   print(sprintf("%s, %s, %s, %s, %s, %s", dd, d, ms, m, t, s))
}

dd2dmsTest <- function()
# unit test for dd2dms
{

  rr <- dd2dms(c(-345.011,5.5,0,0.0000001,0.0001,5.555, NA))
  ee <- c("-345:00:39.6", "05:30:00.0", "00:00:00.0", "00:00:00.0"
         ,"00:00:00.4", "05:33:18.0", NA
         )
  checkEquals(ee,rr, "Error: dd2dms conversion is incorrect")
}

