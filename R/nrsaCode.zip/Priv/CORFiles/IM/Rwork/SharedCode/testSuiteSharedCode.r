# testSuiteSharedCode.r
#
# Defines and runs the test suite for the shared functions EXCLUDING database
# change tracking functions
#
# 03/03/10 cws Created.
# 12/15/11 cws Moved dd* and validation* tests to other suites.
#

require(RUnit)

testSuiteSharedCode <- function()
# Define and run the test suite for the general shared functions (excluding
# db and validation functions)
#
# Results are saved to timestamped HTML file
#
# Note: RUnit does not allow Perl-style regexps, so this one is built on the
# fly to exclude the unit tests we do not want.  Were Perl regexp used, it
# would be sufficient to set testFileRegexp = "^(\\?\\!stVal|\\?\\!db).*\\.r$"
# where the ?! construct specifies the following word should NOT occur.
# In addition, specifying that the words should occur {0,0} times does not work.
# Consequently we're left with brute force methods.
{
  flist <- grep("^(?!stVal|db|dd|validation).*\\.r$"
               ,list.files('l:/Priv/CORFiles/IM/Rwork/SharedCode/'
                          ,pattern='*.r$'
                          )
               ,value=TRUE, perl=TRUE
               )
  re <- paste('(', paste(flist,collapse='|'), ')', sep='')
  testSuite <- defineTestSuite('Shared general functions'
                              ,dirs='l:/Priv/CORFiles/IM/Rwork/SharedCode'
                              ,testFileRegexp=re
                              ,testFuncRegexp="^.+Test$"
                              )

  testResult <- runTestSuite(testSuite)

  testResultFile <- 'l:/Priv/CORFiles/IM/Rwork/SharedCode/testResults_SharedCode.html'
  printHTMLProtocol(testResult, fileName=testResultFile)

}
