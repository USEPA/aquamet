# transectNumber.r
# Converts a vector of transect values to integer codes (A=1, B=2, ... K=11).
# Returns a vector of converted integer codes the same length as the input
# vector.  Where an element is not a recognized transect name, the output
# vector element is NA.
#
#  1-26-2011 cws Created.
#

transectNumber <- function(v)
# Converts a vector of transect values to integer codes (A=1, B=2, ... K=11).
# Returns a vector of converted integer codes the same length as the input
# vector.  Where an element is not a recognized transect name, the output
# vector element is NA.
#
# ARGUMENTS:
# v         vector of transect values to convert to numeric codes
#
{
  # transectCodes <- c(LETTERS[1:11], paste('X',LETTERS[1:11], sep=''))
  transectCodes <- LETTERS[1:11]
  codes <- char2ASCII(v, lookup=transectCodes)
  return(codes)
}


transectNumberTest <- function()
# unit test for transectNumber()
{
  rr <- transectNumber(c(LETTERS[1:11], paste('X', LETTERS[1:11], sep='')))
  ee <- c(1:11, rep(NA,11))
  checkIdentical(ee, rr
                ,"Error: did not correctly convert transect values. to indices"
                )

  rr <- transectNumber(as.character(1:100))
  ee <- rep(NA,100)
  checkIdentical(ee, rr
                ,"Error: did not correctly handle input of non-transect values"
                )

}
# end of file