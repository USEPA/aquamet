# mem.dir.r
#
# 04/20/10 cws created

mem.dir <- function(sort='-mem', filter='all', first='10')
# Returns a directory-like listing of user defined objects in memory.
# Specifies the type, mode, class and size of each object.  Output may be
# ordered by object name or size, and may be filtered by type, mode, class
# or a maximum count of objects listed.
#
# ARGUMENTS:
# sort       optional argument specifying 'mem' or 'alpha'[betic] ordering of
#              the output
# filter     optional argument specifying the class(es) of objects to include in
#              the output.  This argument may be a vector of length > 1, but
#              should be comprised of values 'func'[tions], 'data'[frames],
#              'other'[variables], or it may be NULL or 'all', in which case
#              all objects in memory will be included.
# first      optional argument specifying the number of objects to include
#              in the output
#
{

  # parse arguments into standard values, allowing some degree of abbreviation
  if(substr(tolower(sort),1,3) == 'mem') {
      sorting='+mem'
  } else if(substr(tolower(sort),1,4)=='+mem') {
      sorting='+mem'
  } else if(substr(tolower(sort),1,4)=='-mem') {
      sorting='-mem'
  } else if(substr(tolower(sort),1,3)=='alp') {
      sorting='+alphabetic'
  } else if(substr(tolower(sort),1,4)=='+alp') {
      sorting='+alphabetic'
  } else if(substr(tolower(sort),1,4)=='-alp') {
      sorting='-alphabetic'
  } else {
      return("Incorrect 'sort' argument: must be 'mem','alpha', '+mem','+alpha', '-mem','-alpha'")
  }
  
  if(first %in% c('all',NULL)) {
      nObj <- NULL
  } else if(is.numeric(as.numeric(first)) & first>0) {
      nObj <- as.integer(first)
  } else {
      return("Incorrect 'first' argument: must be 'all', NULL, or a positive integer")
  }
  
  kinds <- NULL
  if(any(substr(filter,1,4) == 'func')) {
      kinds <- c(kinds, 'function')
  }
  if(any(substr(filter,1,4) == 'data')) {
      kinds <- c(kinds, 'data.frame')
  }
  if(any(substr(filter,1,3) == 'oth')) {
      kinds <- c(kinds, 'other')
  }
  if(any(filter == 'all') | is.null(filter)) {
      kinds <- 'all'
  }
  
  # get information for all objects in memory of top environment.
  objs <- ls(pos=+1)
  
  size <- sapply(objs, function(x) { object.size(get(x)) })
  size <- as.data.frame(size, row.names=names(size), stringsAsFactors=FALSE)
  size$name <- row.names(size)

  type <- sapply(objs, function(x) { typeof(get(x)) })
  type <- as.data.frame(type, row.names=names(type), stringsAsFactors=FALSE)
  type$name <- row.names(type)

  class <- sapply(objs, function(x) { class(get(x)) })
  class <- as.data.frame(class, row.names=names(class), stringsAsFactors=FALSE)
  class$name <- row.names(class)

  mode <- sapply(objs, function(x) { mode(get(x)) })
  mode <- as.data.frame(mode, row.names=names(mode), stringsAsFactors=FALSE)
  mode$name <- row.names(mode)
  
  info <- merge(merge(size, type, by='name', all=TRUE)
               ,merge(mode, class, by='name', all=TRUE)
               ,by='name', all=TRUE
               )


  # Manipulate the information as specified.  First filter out unwanted classes,
  # then order them appropriately, and finally limit their number in the output.
  if(all(kinds == 'all')) {
      infoOut <- info
  } else {

      keepClasses <- NULL

      if('other' %in% kinds) {
          keepClasses <- c(keepClasses
                          ,unique(info$class)[!unique(info$class) %in% c('function','data.frame')]
                          )
      }
      if('function' %in% kinds) {
          keepClasses <- c(keepClasses, 'function')
      }
      if('data.frame' %in% kinds) {
          keepClasses <- c(keepClasses, 'data.frame')
      }

      infoOut <- subset(info, class %in% keepClasses)
  }


  if(sorting =='+mem') {
      infoOut <- infoOut[order(infoOut$size),]
  } else if(sorting == '-mem') {
      infoOut <- infoOut[order(-infoOut$size),]
  } else if(sorting =='+alpha') {
      infoOut <- infoOut[order(infoOut$name),]
  } else if(sorting == '-alpha') {
      infoOut <- infoOut[order(-infoOut$name),]
  }
  row.names(infoOut) <- NULL


  if(!is.null(nObj)) infoOut <- infoOut[1:min(nrow(infoOut),nObj),]


  # Write memory synopsis to touput
  print(sprintf("Memory use current/max used/max allowed: %5.2f / %5.2f / %5.2f Mb"
               ,memory.size(), memory.size(max=TRUE), memory.limit()
               ))

  # return object information
  return(infoOut)
}
