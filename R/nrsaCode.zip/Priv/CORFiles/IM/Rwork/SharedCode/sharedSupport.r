# sharedSupport.r
#
# Contains functions and definitions of general utility for the EPA assessment
# metrics calculations
#
# 07/28/08 cws created
# 09/17/08 cws removed inclusion of _nlaOptions.r
#  9/18/08 cws rewrote rename() to correctly rename columns.
#  9/22/08 cws rewrote modalClass() to simplify it and to correctly assign
#          class names to the modal values.  Like the previous fix to rename(),
#          this problem was based on an incorrect assumption about the order 
#          of column names, and in this case was fixed by enforcing the 
#          expected order in the function.  Created renameTest(), for obvious 
#          reasons, and funcTestOutput() to support it.
# 10/09/08 cws Added definition of normalizedCover().
# 10/14/08 cws fixed normalizedCover() bug which resulted in tt$.coverNorm
#          being type data.frame, which later prevented merge() or rbind() from 
#          completing within memory constraints.  tt[coverValue] required
#          unlist()ing to result in proper type of tt$.coverNorm.
# 10/17/08 cws idr() changed to use type 2 quantile calculation method, as this
#          matches SAS output using proc univariate.  Created iqr() to calculate
#          IQR using choice of methods.
# 10/20/08 cws Modified normalizedCover() to allow classes summing to less than
#          100%, for those cases where the categories do not exhaust all 
#          possibilities.
# 10/21/08 cws Completed normalizedCoverTest().
# 10/29/08 cws Removed deprecated functions, added nlaWiden and nlaLengthen
# 11/18/08 cws Added definitions for trimws() and uidSeparate(), and rewrote
#          uidCreate() to be more general (and quicker).
#  2/02/09 cws Changed output of diff() to denote dataframes being compared as
#          First and Second instead of x and y.  Numeric and non-numeric 
#          values also tested more thoroughly.
#  2/13/09 cws Fixed comments for nlaLengthen().
#  2/23/09 cws diff() now handles factors and datetimes for comparison, both
#          using coercion.
#  6/18/09 cws Changed nlamets.r to nlaSupport.r
#  8/31/09 cws Removed optional tests (relying on boolean testFunctions) of
#          the functions defined here, relying on RUnit harness instead.
#  9/02/09 cws Added definitions of lag(), lead(), first(), and their unit 
#          tests.
#  9/14/09 cws Added definition for last() and unit test.
#  9/23/09 cws Modified first() and last() to handle missing values as a
#          comparable value different than any other.  Previously, this resulted
#          in NA values in the 'first' and 'last' flag columns.
#  3/04/10 cws Modified unit tests to use RUnit instead of funcTest().
#  3/25/10 cws Renamed diff as dfCompare, nlaWiden to dfWiden and nlaLengthen to
#          dfLengthen.  Renamed file from nlaSupport.r to sharedSupport.r.
# 12/15/11 cws Adding sourcing of shared support functions that are not defined 
#          in this file
#  3/02/12 cws Added selectElements definition
#  5/15/12 cws Modified dfCompare to handle NaN and Inf values; was failing due to 
#          inability to operate on them with abs(vx-vy).  Also simplified
#          check for incomparable values using xor() rather than mix of & and |.
#  5/24/12 cws Added unit test for dfCompare (finally!).
#

require(RUnit)
intermediateMessages <- TRUE

source('l:/Priv/CORFiles/IM/Rwork/SharedCode/beep.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/char2ASCII.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/cleanDataframe.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dfCharacterize.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dfToR.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/greatCircleDistance.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/interpolatePercentile.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/listCompare.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/listToR.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/mem.dir.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/modalCount.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/prepareDataForSAS.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/printTimingInfo.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/removeHighBits.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/selectElements.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/tableOverview.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/tableValidation.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/transectNumber.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/vecToR.r')


count <- function(x) 
# Returns the number of non-missing values in the vector, used to determine
# sample size.  
#
# NOTE: When using this function with aggregate(), it is sometimes necessary 
# to convert x to factors using as.factors() to prevent the output from 
# creating a vector 'if (stringsAsFactors) factor(x) else x' instead of 'x'.
# I do not know why.
#
# ARGUMENTS:
# x        vector of values to count.
{ 

    length(na.omit(x))
}

countTest <- function()
# Performs tests on count().
{
    # create test data.
    idx <- rep(c('foo','bar','baz'),17)
    n <- runif(length(idx))
    n[c(1,2,4,8,16,32)] <- NA
    t <- rep(letters[1:7], length.out=length(idx))
    t[c(1,2,3,5,8,13,21,34)] <- NA
    f <- factor(rep(letters[1:7], length.out=length(idx)))
    f[c(3,14,15,9,26)] <- NA
    mi<- as.integer(rep(NA, length(idx)))
    mc<- as.character(rep(NA, length(idx)))
    df <- data.frame(idx, n, t, f, mi, mc
                    ,stringsAsFactors=FALSE                     
                    )

    # test function behaviour for various types
    checkEquals(51-6, count(n), "Error: count() fails with vector of double")
    checkEquals(51-8, count(t), "Error: count() fails with vector of characters")
    checkEquals(51-5, count(f), "Error: count() fails with vector of factors")
    checkEquals(0, count(mi), "Error: count() fails with vector all missing")
}


dfCompare <- function(df1,df2, byVars, zeroFudge=1e-17, verbose=FALSE)
# Used to find differences in data frames.  Comparisons will be restricted to
# records with equivalent keys and to common columns.  Rows and columns ocuring
# in only one of the data frames will be noted in the output.
#
# Returns a Nx1 matrix of differences.
#
# ARGUMENTS:
# df1, df2  Dataframes to compare.  These must share key variables.
# byVars    Key variables which uniquely identify specific rows in each
#             dataframe.
# zeroFudge Largest difference between numeric values that is regarded as zero.
# verbose   Logical value, if TRUE column names will be printed as they are
#             compared.
#
{

  nFlagged<-0
  diffList <- NULL
  notNumber <- '[a-df-zA-DF-Z _:;=\\/\\|\\?\\*\\(\\)\\$\\^%,<>]'

  # Restrict comparison to common variables, and list variables which
  # occur in only one dataframe.
  n1 <- names(df1)[!(names(df1) %in% byVars)]
  n2 <- names(df2)[!(names(df2) %in% byVars)]
  only1 <- n1[!(n1 %in% n2)]
  only2 <- n2[!(n2 %in% n1)]

  if (length(only1) > 0) {
      diffList <- rbind(diffList
                       ,paste("Variables in first file not in second:"
                             ,paste(only1, collapse=', ')
                             ,sep=''
                             )
                       )
  }
  if (length(only2) > 0) {
      diffList <- rbind(diffList
                       ,paste("Variables in second file not in first:"
                             ,paste(only2, collapse=', ')
                             ,sep=''
                             )
                       )
  }


  # Restrict comparison to common rows as defined by values of key variables
  # listed in byVars argument, and listing those values which occur in only
  # one dataframe.  Note that the [,1] terminus converts the dataframe to an 
  # unnamed vector.
  for(k in 1:length(byVars)) {
      if(k==1) {
          keyValues1 <- df1[byVars[k]][,1]
          keyValues2 <- df2[byVars[k]][,1]
      } else {
          keyValues1 <- paste(keyValues1,df1[byVars[k]][,1], sep=' | ')
          keyValues2 <- paste(keyValues2,df2[byVars[k]][,1], sep=' | ')
      }
  }
  rows1 <- keyValues1[!(keyValues1 %in% keyValues2)]
  rows2 <- keyValues2[!(keyValues2 %in% keyValues1)]

  if (length(rows1) > 0) {
      diffList <- rbind(diffList
                       ,as.matrix(paste("Row in first file not in second:"
                                       ,rows1
                                       ,condense=' '
                                       )
                                 ,ncol=1
                                 )
                       )
  }
  if (length(rows2) > 0) {
      diffList <- rbind(diffList
                       ,as.matrix(paste("Row in second file not in first:"
                                       ,rows2
                                       ,condense=' '
                                       )
                                 ,ncol=1
                                 )
                       )
  }


  # List common variables and prepare for comparison.
  vars <- intersect(n1,n2)
  both <- merge(subset(df1, select=c(byVars, vars))
               ,subset(df2, select=c(byVars, vars))
               ,by=byVars
               ,all=FALSE, sort=TRUE
#               ,suffixes=c('First','Second')
               )


  # Go through each common variable and look for differences
  # Convert factors to 'real' values to allow comparisons.  The class()
  # function returns two classes for some objects (e.g. "POSIXt"  "POSIXct")
  # so any() is used to aggregate the resulting boolean values.
  for(m in 1:length(vars)) {

      if(verbose) print(paste("Checking", vars[m]))

      vx <- both[,paste(vars[m],'.x',sep='')] 
      vy <- both[,paste(vars[m],'.y',sep='')] 
      if(typeof(vx) != typeof(vy)) {
          rbind(diffList
               ,sprintf("Type mismatch for %s: First=<%s> Second=<%s>, converting to character"
                       ,vars[m], typeof(vx),typeof(vy)
                       )
               )
          vx <- as.character(vx)
          vy <- as.character(vy)
      }
      
      if(any(class(vx)=='factor')) {
          if(mode(vx)=='numeric') {
              if(verbose) print("(Converting factor to numeric in first df)")
              vx <- as.numeric(vx)
          } else if(mode(vx)=='character') {
              if(verbose) print("(Converting factor to character in first df)")
              vx <- as.character(vx)
          } else {
              print(paste("Unexpected mode in first df: ", typeof(vx)))
          }   
      }
      if(any(class(vy)=='factor')) {
          if(mode(vy)=='numeric') {
              if(verbose) print("(Converting factor to numeric in second df)")
              vy <- as.numeric(vy)
          } else if(mode(vy)=='character') {
              if(verbose) print("(Converting factor to character in second df)")
              vy <- as.character(vy)
          } else {
              print(paste("Unexpected mode in first df: ", typeof(vy)))
          }   
      }

      for(s in 1:length(both[,1])) {
          
          flagDiff <- FALSE
          if (is.na(vx[s]) & is.na(vy[s])) {
              # Do nothing.
        
          } else if(xor(is.na(vx[s]), is.na(vy[s]))) {
              
              flagDiff <- TRUE
              nFlagged <- nFlagged+1
              
          } else if (mode(vx[s]) == 'numeric' & mode(vy[s]) == 'numeric') {    # handle numeric values
              
              if (is.nan(vx[s]) & is.nan(vy[s])) {
                  # Do nothing.
            
              } else if(xor(is.nan(vx[s]), is.nan(vy[s]))) {
              
                  flagDiff <- TRUE
                  nFlagged <- nFlagged+1
              
              } else if(xor(is.infinite(vx[s]), is.infinite(vy[s]))) {
              
                  flagDiff <- TRUE
                  nFlagged <- nFlagged+1
              
              } else if (is.infinite(vx[s]) & is.infinite(vy[s])) {
                  
                  # these are comparable, but can't operate on them
                  if(vx[s] != vy[s]) {
                      flagDiff <- TRUE
                      nFlagged <- nFlagged+1                      
                  }
                  
              } else if (abs(as.double(vx[s] - vy[s])) > zeroFudge) {
                  
                  flagDiff <- TRUE
                  nFlagged <- nFlagged+1
                  
              }
              
          } else {                                                              # handle character values
              
              if(as.character(vx[s]) != as.character(vy[s]) ) {
                  flagDiff <- TRUE
                  nFlagged <- nFlagged+1
              }
          }

          if(flagDiff) {
              for(k in 1:length(byVars)) {
                  if(k==1) {
                      keyValues <- paste(byVars[k]
                                        ,both[s,names(both)==byVars[k]]
                                        ,sep='='
                                        )
                  } else {
                      keyValues <- paste(keyValues
                                        ,paste(byVars[k]
                                              ,both[s,names(both)==byVars[k]]
                                              ,sep='='
                                              )
                                        ,sep=', '
                                        )
                  }
              }
              diffList <- rbind(diffList,
                                sprintf("Difference at %s; %s: First=<%s> Second=<%s>"
                                       ,keyValues, vars[m]
                                       ,as.character(vx[s]) 
                                       ,as.character(vy[s]) 
                                       )
                               )
          }
      }
  }

  return(diffList)
} 


dfCompareTest <- function()
# Unit test for dfCompare
{
    # Test for false differences:
    aa <- data.frame(a = c(1:10, NA, Inf)
                    ,b = c(seq(0,1, length=10), NA, Inf)
                    ,c = c(letters[1:10], NA, NA)
                    ,d = as.factor(LETTERS[c(1:10, NA, NA)])
                    ,e = c(FALSE, TRUE, FALSE, FALSE, TRUE,FALSE, TRUE, FALSE, FALSE, TRUE, NA, NA)
                    ,stringsAsFactors=FALSE
                    )
   
    dd <- try( dfCompare(aa, aa, c('a')) , silent=TRUE)
    checkTrue(class(dd) != 'try-error', paste("Caught error in dfCompare between identical dataframes: ", as.character(dd)))
    checkEquals(NULL, dd, "Detected differences in identical dataframes")
    
    # Test for ability to compare across classes
    bb <- within(aa
                ,{a = as.character(a)
                  b = as.character(b)
                  c = as.factor(c)
                  d = LETTERS[c(1:10, NA, NA)]
                 }
                )
    dd <- try( dfCompare(aa, bb, c('a')) , silent=TRUE)
    checkTrue(class(dd) != 'try-error', paste("Caught error in dfCompare testing with class variation: ", as.character(dd)))
    checkEquals(NULL, dd, "Detected differences in dataframes varying by class")
    
    # Test if we can detect differences
    bb <- within(aa
                ,{b = c(seq(0,1, length=10), Inf, NA)       # Comparing NA, Inf
                  c = c(letters[1:12])                      # comparing NA, character
                  d = c(1:11,11)                            # comparing factor to integer
                  f = 'x'                                   # column not in other dataframe
                 }
                )
    exp <- as.matrix(c("Variables in second file not in first:f"          # column not in other dataframe
                      ,"Difference at a=Inf; b: First=<Inf> Second=<NA>"  # Comparing NA, Inf
                      ,"Difference at a=NA; b: First=<NA> Second=<Inf>"   
                      ,"Difference at a=Inf; c: First=<NA> Second=<l>"    # comparing NA, character
                      ,"Difference at a=NA; c: First=<NA> Second=<k>"     
                      ,"Difference at a=1; d: First=<A> Second=<1>"       # comparing factor to integer
                      ,"Difference at a=2; d: First=<B> Second=<2>"     
                      ,"Difference at a=3; d: First=<C> Second=<3>"     
                      ,"Difference at a=4; d: First=<D> Second=<4>"     
                      ,"Difference at a=5; d: First=<E> Second=<5>"     
                      ,"Difference at a=6; d: First=<F> Second=<6>"     
                      ,"Difference at a=7; d: First=<G> Second=<7>"     
                      ,"Difference at a=8; d: First=<H> Second=<8>"     
                      ,"Difference at a=9; d: First=<I> Second=<9>"     
                      ,"Difference at a=10; d: First=<J> Second=<10>"   
                      ,"Difference at a=Inf; d: First=<NA> Second=<11>" 
                      ,"Difference at a=NA; d: First=<NA> Second=<11>"  
                      )
                    ,nrow=1)
    dd <- try( dfCompare(aa, bb, c('a')) , silent=TRUE)
#    return(dd)
    checkTrue(class(dd) != 'try-error', paste("Caught error in dfCompare with differing values: ", as.character(dd)))
    checkEquals(exp, dd, "Detected unexpected differences in dataframes with different values")

    
}


first<-function(df,v,first.v)
# Mimics the SAS FIRST. operator by creating a new column containing a boolean
# flag which is TRUE if the row has different by-variable values than the
# preceding row.  Returns dataframe with flag in added column.
#
# Ordering the input dataframe prior to using this function is not required, but
# will be useful.
#
# ARGUMENTS:
# df        dataframe to add 'first' flag column to
# v         name of existing column in dataframe with values to
# lead.v    names of new column in dataframe to contain first flag values
#
{
  # Lag named column by one row into temporary column
  df <- lag(df, v, '..vLag', offset=1)

  # A row is flagged 'first' if the named column is changed from the previous
  # row, otherwise they are not.  The comparison must be coerced into a vector
  # to allow the 'first' column to be named properly.  Missing (NA) values in
  # either the data column or it's lag() value are treated as comparable values
  # A row is flagged as first if the value v is not the same as the lagged value
  # of v OR if their inequality is NA and v and lag(v) are not both NA.
  # The old check ( df[first.v] <- as.vector(df[v] != df['..vLag']) ) resulted
  # in first=NA if either v or vLag were NA.
  df[first.v] <- as.vector(ifelse(is.na(df[v]) | is.na(df['..vLag'])
                                 ,is.na(df[v]) != is.na(df['..vLag'])
                                 ,df[v] != df['..vLag']
                                 )
                          )

  # The first row must be 'first' by definition; if it is not explicitly set,
  # the comparison will be NA.
  df[1,first.v] <- TRUE

  # Drop temporary column
  df['..vLag'] <- NULL

  return(df)
}

firstTest <- function()
# tests first()
{
  # Create test dataframe
  dfTest <- data.frame('a' = rep(1:3, each=20)
                      ,'b' = rep(1:4, each=5, times=3)
                      ,'c' = rep(1:5, times=12)
                      ,stringsAsFactors=FALSE
                      )
  dfTest$x <- runif(length(dfTest))

  # Try flagging column a
  result <- first(dfTest, 'a', 'first.a')
  expected <- dfTest
  expected$first.a <- ifelse(expected$b==1 & expected$c==1, TRUE, FALSE)
  checkIdentical(expected, result
                ,"ERROR: first() did not correctlyflag column a"
                )

  # Try flagging column b
  result <- first(dfTest, 'b', 'first.b')
  expected <- dfTest
  expected$first.b <- ifelse(expected$c==1, TRUE, FALSE)
  checkIdentical(expected, result
                ,"ERROR: first() did not correctly flag column b"
                )

  # Try flagging b when it has missing values
  missTest <- dfTest
  missTest[missTest$a==1 &
           missTest$b %in% c(1,3) &
           missTest$c %in% c(1,2)
          ,]$b <- NA

  result <- first(missTest, 'b', 'first.b')
  expected <- missTest
  expected$first.b <- ifelse(expected$c==1, TRUE, FALSE)
  expected[expected$a == 1 &
           expected$b %in% c(1,3) &
           expected$c == 3
          ,]$first.b <- TRUE
  checkIdentical(expected, result
                ,"ERROR: first() did not correctly flag column b with missing values"
                )


}


funcTestDEPRECATED <- function(f, x, y, testDesc, verbose=FALSE, fudge=10^(-13))
# Used to test basic functions, returns text description of test results
# 
# ARGUMENTS:
# f        Function to test
# x        Test input data
# y        Expected results from function being tested
# testDesc Short description of test
# verbose  If TRUE, causes return of positive results, otherwise only returns
#          notice of failure
# fudge    Allowable difference in calculation results to pass test.
{
    response <- NULL;

    if(is.null(y)) {

        # expected output is NULL
        pass <- is.null(f(x))

    } else if(is.matrix(y) | is.data.frame(y)) {

        # expected output is a matrix
        pass <- identical(f(x), y)

    } else {

        # expected output is a scalar or vector value
        if(is.numeric(y) && length(y)==1) {
            pass <- (abs(f(x)- y) <= fudge)
        }
        else {
            pass <- ((f(x) == y) || (is.na(f(x)) && is.na(y))) 
        }
    }

    funcTestOutput(pass, verbose, testDesc)

}

funcTest2DEPRECATED <- function(f, x1, x2, y, testDesc, verbose=FALSE, fudge=10^(-13))
# Used to test basic functions, returns text description of test results
# 
# ARGUMENTS:
# f        Function to test
# x1       Test input argument 1
# x2       Test input argument 2
# y        Expected results from function being tested
# testDesc Short description of test
# verbose  If TRUE, causes return of positive results, otherwise only returns
#          notice of failure
# fudge    Allowable difference in calculation results to pass test.
{
    response <- NULL;

    if(is.numeric(y) && length(y)==1) {
        pass <- (abs(f(x1,x2)- y) <= fudge)
    }
    else {
        pass <- ((f(x1,x2) == y) || (is.na(f(x1,x2)) && is.na(y))) 
    }

    funcTestOutput(pass, verbose, testDesc)

}

funcTest3DEPRECATED <- function(f, x1, x2, x3, y, testDesc, verbose=FALSE, fudge=10^(-13))
# Used to test basic functions, returns text description of test results
# 
# ARGUMENTS:
# f        Function to test
# x1       Test input argument 1
# x2       Test input argument 2
# x3       Test input argument 3
# y        Expected results from function being tested
# testDesc Short description of test
# verbose  If TRUE, causes return of positive results, otherwise only returns
#          notice of failure
# fudge    Allowable difference in calculation results to pass test.
{
    response <- NULL;

    if(is.numeric(y) && length(y)==1) {
        pass <- (abs(f(x1, x2, x3)- y) <= fudge)
    }
    else {
        pass <- ((f(x1, x2, x3) == y) || (is.na(f(x1, x2, x3)) && is.na(y))) 
    }

    funcTestOutput(pass, verbose, testDesc)

}


funcTestOutputDEPRECATED <- function(pass, verbose, testDesc)
# Write output for funcTest functions.  Code should be self-explainatory.
{
    if(pass && verbose) cat('OK:     ',testDesc,'\n')
    else if (!pass)     cat('Failed: ',testDesc,'\n')
}


gmean <- function(x)
# Returns the geometric mean of the specified data
#
# ARGUMENTS:
# x        Vector of values of interest.
#
{
  prod(x)^(1/count(x))
}


idr <- function(x, method=2)
# Returns interdecile range (90%-10% of population, assuming gaussian
# distribution) of the specified data.  Quantile calculation type 2 matches
# SAS to within 10^-6 100% of the time (for 2008 data); this is at odds with
# the R documentation which specifies type 3 imitates SAS.  FWIW, type 5 
# differs from SAS only 7% of the time under the same conditions.
#
# ARGUMENTS:
# x        Vector of values of interest.
#
{ 
    quantile(x, probs=0.90, na.rm=TRUE, names=FALSE, type=method) - 
      quantile(x, probs=0.10, na.rm=TRUE, names=FALSE, type=method)
}

idrTest <- function()
# tests idr()
{
    # test function behaviour for various types
    checkEquals(160, idr(seq(-100,100,0.1)), "Error: idr fails with doubles #1")
    checkEquals(164.4, idr(seq(-100,100,13.7)), "Error: idr fails with doubles #2")
    checkTrue(is.na(idr(as.integer(rep(NA, 43)))), "Error: idr fails with all NA")
    checkEquals(0, idr(1.2), "Error: idr fails with single value")
}


iqr <- function(x, method=2)
# Returns interquartile range (75%-25% of population, assuming gaussian
# distribution) of the specified data.  Quantile calculation type 2 matches
# SAS to within 10^-6 100% of the time (for 2008 data); this is at odds with
# the R documentation which specifies type 3 imitates SAS.  FWIW, type 5 
# differs from SAS only 7% of the time under the same conditions.
#
# ARGUMENTS:
# x        Vector of values of interest.
#
{ 
    quantile(x, probs=0.75, na.rm=TRUE, names=FALSE, type=method) - 
      quantile(x, probs=0.25, na.rm=TRUE, names=FALSE, type=method)
}

iqrTest <- function()
# tests idr()
{
    # test function behaviour for various types
    checkEquals(100, iqr(seq(-100,100,0.1)), "Error: idr fails with doubles #1")
    checkEquals(109.6, iqr(seq(-100,100,13.7)), "Error: idr fails with doubles #2")
    checkTrue(is.na(iqr(as.integer(rep(NA, 43)))), "Error: idr fails with all NA")
    checkEquals(0, iqr(1.2), "Error: idr fails with single value")
}


is.subset <- function(a,b)
# Returns TRUE if elements in vector a are a subset of the elements in vector 
# b, or FALSE otherwise.
#
# ARGUMENTS:
# a        A vector of elements of which all elements are expected to be
#          found in vector b.
# b        A vector of elements which is expected to contain all of the 
#          elements of a.
#
{
  return(sum( (unique(a) %in% unique(b)) ) == sum( rep(TRUE,length(a))) )
}

is.subsetTest <- function()
# Tests is.subset
{

  # Test numbers in various guises: as numbers
  checkEquals(TRUE, is.subset(c(1,2,4,8), rep(1:10))
             ,"Error: is.subset fails with number vector #1"
             )
  checkEquals(FALSE, is.subset(c(1,2,4,8,101), rep(1:10))
             ,"Error: is.subset fails with number vector #2"
             )

  # Test numbers in various guises: as list elements
  checkEquals(TRUE, is.subset(as.list(c(1,2,4,8)), rep(1:10))
             ,"Error: is.subset fails with number list #1"
             )
  checkEquals(FALSE, is.subset(as.list(c(1,2,4,8,101)), rep(1:10))
             ,"Error: is.subset fails with number list #2"
             )

  # Test characters in various guises: as characters
  checkEquals(TRUE, is.subset(c(1,2,4,8), rep(1:10))
             ,"Error: is.subset fails with character vector #1"
             )
  checkEquals(FALSE, is.subset(c(1,2,4,8,101), rep(1:10))
             ,"Error: is.subset fails with character vector #2"
             )

}


intermediateMessage <- function (text, loc='middle') 
# Display brief message(s) during metrics calculation, if enabled by 
# intermediateMessages
#
# ARGUMENTS:
# text     Character variable with text to display
# loc      Either 'start','middle' or 'end', used to describe whether
#          the location of a section for which intermediate results are
#          wanted.  This value is used to affect the display format.
{
  if(intermediateMessages) {
      outText <- text
      if(loc=='start') outText <- paste('  ',outText, sep='')
      if(loc=='end') outText <- paste(outText, '\n', sep='')
      cat(outText)
  }
}


lag<-function(df,v,lag.v, offset=1)
# Mimics the SAS LAGx() function by creating new column(s) containing the
# values of the specified column(s) from the previous row.
#
# Returns the input dataframe with the lagged values in new column(s) with the
# specified name(s).
#
# e.g. lag(df, 'substrate', 'substrate.2', offset=2)
#         input df: key substrate     output df: key substrate substrate.2
#                   1   FN                       1   FN        <NA>
#                   2   GF                       2   GF        <NA>
#                   3   SA                       3   SA        FN
#                   4   XB                       4   XB        GF
#                   5   CB                       5   CB        SA
#
#
#
# ARGUMENTS:
# df        dataframe to add lag columns to
# v         names of existing columns in dataframe with values to lag
# lag.v     names of new columns in dataframe to contain lagged values
# offset    integer value specifying the number of rows to lag the value by,
#             defaulting to 0.
#
# ASSUMPTIONS:
#
{
  # Sanity check
  if(length(v) != length(lag.v)) {
       stop("Error: number of column names not same as number of lagged names")
  }

  # Lagging single columns is slightly different than multiple columns as
  # I've been unable to get one method that works for both.
  if(length(v)==1) {
      df[lag.v] <-     c(matrix(rep(NA,offset*length(v))
                               ,nrow=offset, ncol=length(v)
                               )
                        ,df[1:(nrow(df)-offset),v]
                        )
  } else {
      df[lag.v] <- rbind(matrix(rep(NA,offset*length(v))
                               ,nrow=offset, ncol=length(v)
                               ,dimnames=list(NULL,v)
                               )
                        ,df[1:(nrow(df)-offset),v]
                        )
  }

  return(df)
}

lagTest <- function()
# Tests the lag() function
{
  # Create test dataframe
  dfTest <- data.frame('a'=LETTERS
                      ,'b'=letters
                      ,'c'=1:length(LETTERS)
                      ,stringsAsFactors=FALSE
                      )
  
  # Try lagging single column
  result <- lag(dfTest, 'c', 'prev.c')
  expected <- dfTest
  expected$prev.c <- c(NA, 1:(nrow(dfTest) - 1))
  checkIdentical(expected, result
                ,"ERROR: lag() of single column failed"
                )
  
  # Try lagging multiple columns
  result <- lag(dfTest, c('c','b'), c('prev.c','prev.b'), 3)
  expected <- dfTest
  expected$prev.c <- c(NA, NA, NA, 1:(nrow(dfTest) - 3))
  expected$prev.b <- c(NA, NA, NA, letters[1:(nrow(dfTest) - 3)])
  checkIdentical(expected, result
                ,"ERROR: lag() of multiple columns failed"
                )

}


last<-function(df,v,last.v)
# Mimics the SAS LAST. operator by creating a new column containing a boolean
# flag which is TRUE if the row has different by-variable values than the
# following row.  Returns dataframe with flag in added column.
#
# Ordering the input dataframe prior to using this function is not required, but
# will be useful.
#
# ARGUMENTS:
# df        dataframe to add 'first' flag column to
# v         name of existing column in dataframe with values to
# last.v    names of new column in dataframe to contain first flag values
#
{
  # Lead named column by one row into temporary column
  df <- lead(df, v, '..vLead', offset=1)

  # A row is flagged 'last' if the named column changes in the next row,
  # otherwise they are not.  The comparison must be coerced into a vector
  # to allow the 'last' column to be named properly.  The last row must be
  # 'last' by definition; if it is not explicitly set, the comparison will be
  # NA.
  #df[last.v] <- as.vector(df[v] != df['..vLead'])
  # A row is flagged 'last' if the named column is changed from the previous
  # row, otherwise they are not.  The comparison must be coerced into a vector
  # to allow the 'last' column to be named properly.  Missing (NA) values in
  # either the data column or it's lead() value are treated as comparable values
  # A row is flagged as last if the value v is not the same as the leaded value
  # of v OR if their inequality is NA and v and lead(v) are not both NA.
  # The old check ( df[last.v] <- as.vector(df[v] != df['..vLead']) ) resulted
  # in first=NA if either v or vLead were NA.
  df[last.v] <- as.vector(ifelse(is.na(df[v]) | is.na(df['..vLead'])
                                 ,is.na(df[v]) != is.na(df['..vLead'])
                                 ,df[v] != df['..vLead']
                                 )
                          )

  # The last row must be 'last' by definition; if it is not explicitly set, the
  # comparison will be NA.
  df[nrow(df), last.v] <- TRUE

  # Drop temporary column
  df['..vLead'] <- NULL

  return(df)
}

lastTest <- function()
# tests last()
{
  # Create test dataframe
  dfTest <- data.frame('a' = rep(1:3, each=20)
                      ,'b' = rep(1:4, each=5, times=3)
                      ,'c' = rep(1:5, times=12)
                      ,stringsAsFactors=FALSE
                      )
  dfTest$x <- runif(length(dfTest))

  # Try flagging column a
  result <- last(dfTest, 'a', 'last.a')
  expected <- dfTest
  expected$last.a <- ifelse(expected$b==4 & expected$c==5, TRUE, FALSE)
  checkIdentical(expected, result
                ,"ERROR: last() did not flag column a correctly"
                )

  # Try flagging column b
  result <- last(dfTest, 'b', 'last.b')
  expected <- dfTest
  expected$last.b <- ifelse(expected$c==5, TRUE, FALSE)
  checkIdentical(expected, result
                ,"ERROR: last() did not flag column b correctly"
                )

  # Try flagging b when it has missing values
  missTest <- dfTest
  missTest[missTest$a==1 &
           missTest$b %in% c(1,3) &
           missTest$c %in% c(1,2)
          ,]$b <- NA

  result <- last(missTest, 'b', 'last.b')
  expected <- missTest
  expected$last.b <- ifelse(expected$c==5, TRUE, FALSE)
  expected[expected$a == 1 &
           is.na(expected$b) &
           expected$c == 2
          ,]$last.b <- TRUE
  checkIdentical(expected, result
                ,"ERROR: last() did not correctly flag column b with missing values"
                )
}


lead<-function(df,v,lead.v, offset=1)
# Antimimics the SAS LAGx() function by creating a new column containing the
# values of the specified column from the next row.
#
# Returns the input dataframe with the anti-lagged values in a new column with
# the specified name.
#
# e.g. lead(df, 'substrate', 'substrate.2', offset=2)
#         input df: key substrate     output df: key substrate substrate.2
#                   1   FN                       1   FN        SA
#                   2   GF                       2   GF        XB
#                   3   SA                       3   SA        CB
#                   4   XB                       4   XB        <NA>
#                   5   CB                       5   CB        <NA>
#
#
#
# ARGUMENTS:
# df        dataframe to add lead columns to
# v         names of existing columns in dataframe with values to lead
# lead.v    names of new columns in dataframe to contain lead values
# offset    integer value specifying the number of rows to lead the value by,
#             defaulting to 0.
#
# ASSUMPTIONS:
#
{
  # Sanity check
  if(length(v) != length(lead.v)) {
       stop("Error: number of column names not same as number of lagged names")
  }

  # Leading single columns is slightly different than multiple columns as
  # I've been unable to get one method that works for both.
  if(length(v)==1) {
      df[lead.v] <-     c(df[(1+offset):nrow(df), v]
                         ,matrix(rep(NA,offset*length(v))
                                ,nrow=offset, ncol=length(v)
                                )
                         )
  } else {
      df[lead.v] <- rbind(df[(1+offset):nrow(df), v]
                         ,matrix(rep(NA,offset*length(v))
                                ,nrow=offset, ncol=length(v)
                                ,dimnames=list(NULL,v)
                                )
                         )
  }

  return(df)
}

leadTest <- function()
# Tests the lead() function
{
  # Create test dataframe
  dfTest <- data.frame('a'=LETTERS
                      ,'b'=letters
                      ,'c'=1:length(LETTERS)
                      ,stringsAsFactors=FALSE
                      )

  # Try lagging single column
  result <- lead(dfTest, 'c', 'prev.c')
  expected <- dfTest
  expected$prev.c <- c(2:nrow(dfTest), NA)
  checkIdentical(expected, result
                ,"ERROR: lead() of single column failed"
                )

  # Try lagging multiple columns
  result <- lead(dfTest, c('c','b'), c('prev.c','prev.b'), 3)
  expected <- dfTest
  expected$prev.c <- c(4:nrow(dfTest), NA, NA, NA)
  expected$prev.b <- c(letters[4:nrow(dfTest)], NA, NA, NA)
  checkIdentical(expected, result
                ,"ERROR: lead() of multiple columns failed"
                )

}


modalClass <- function(x, values, classes)
# Determines most common classes, based on counts for each class.  Counts are
# expected to occur in the same row (i.e. long format).  This function is
# intended to be called from within a loop.  In the case of ties, all modal
# classes will be included, separated by a comma and a space. e.g.
#
#     foo<-subset(df, select='uid')
#     foo$mode <- NA
#     for(i in 1:nrow(df)) {
#       foo$mode[i] <- modalClass(df[i]
#                                , c('count1','count2','count3'...)
#                                , c('ones','twos','threes',...)
#                                )
#     }
#
#
# ARGUMENTS:
# x        named values of interest, e.g. a single row of a dataframe
# values   list of column names in x containing cover or other values on
#          which the modal class will be based.
# classes  list of class names associated with the columns, given in the order
#          that the values are listed.
#
# ASSUMPTIONS
# Column names listed by values arg occur in x.
# The list of class names is in the same order as the list of 
# The number of elements in values is the number of elements in classes.
#
{
  # separate quantities of interest in the row, just as a shortcut
  qq <- x[values]

  if(all(is.na(qq))) {
      # Mode is undefined if all values in row are missing.
      modalClasses <- NA

  } else {
      # determine locations of maximum value as a series of boolean values
      # and change any NA to FALSE
      bb <- qq==max(qq, na.rm=TRUE)
      bb <- bb==TRUE & !is.na(bb)

      # select the most common class names based on the maxima of the values
      # which were just selected.  
      modalClasses <- paste(classes[bb], collapse=', ')
  }

  return(modalClasses)
}

modalClassTest <- function()
{
    # create test data.
    dfTest<-data.frame(idx1=c('one','two','two','three')
                      ,idx2=c(1,1,2,3)
                      ,coverA=c(1, 1, 1 ,NA)
                      ,coverB=c(2, 2, 2 ,NA)
                      ,coverC=c(1, 1, NA,NA)
                      ,coverD=c(3, 3, 3 ,NA)
                      ,coverE=c(2, 2, NA,NA)
                      ,coverF=c(0, 3, 3 ,NA)
                      ,coverG=c(2, 2, 2 ,NA)
                      ,coverH=c(0, 2, 3 ,NA)
                      )

    # test function behaviour
    checkEquals('D'
               ,modalClass(dfTest[1,]
                          ,c('coverA','coverB','coverC','coverD'
                            ,'coverE','coverF','coverG','coverH'
                            )
                          ,LETTERS[1:8]
                          )
               ,"Error: modalClass failed with single mode"
               )
    checkEquals('D, F'
               ,modalClass(dfTest[2,]
                          ,c('coverA','coverB','coverC','coverD'
                            ,'coverE','coverF','coverG','coverH'
                            )
                          ,LETTERS[1:8]
                          )
               ,"Error: modalClass failed with two modes"
               )
    checkEquals('D, F, H'
               ,modalClass(dfTest[3,]
                          ,c('coverA','coverB','coverC','coverD'
                            ,'coverE','coverF','coverG','coverH'
                            )
                          ,LETTERS[1:8]
                          )
               ,"Error: modalClass failed with three modes and missing values"
               )
    checkEquals('D, F, H'
               ,modalClass(dfTest[3,]
                          ,c('coverA','coverC','coverE','coverG'
                            ,'coverB','coverD','coverF','coverH'
                            )
                          ,c('A','C','E','G','B','D','F','H')
                          )
               ,"Error: modalClass failed with three modes and missing values, names reordered"
               )
    checkTrue(is.na(modalClass(dfTest[4,]
                              ,c('coverA','coverB','coverC','coverD'
                                ,'coverE','coverF','coverG','coverH'
                                )
                              ,LETTERS[1:8]
                              )
                   )
             ,"Error: modalClass failed with all missing values"
             )

}


modalvalue <- function(x, na.rm=FALSE)
# Returns the mode of the specified data. This function was taken from the R 
# wiki site:
# http://wiki.r-project.org/rwiki/doku.php?id=tips:stats-basic:modalvalue
#
# NOTE: It might be good to make sure x is a vector of numbers instead of just 
# flattening it with unlist().
# NOTE: When using this function with aggregate(), it is sometimes necessary 
# to convert x to factors using as.factors() to prevent the output from 
# creating a vector 'if (stringsAsFactors) factor(x) else x' instead of 'x'.
# I do not know why.
#
# ARGUMENTS:
# x        vector of values of interest
# na.rm    If TRUE, will remove NA values from consideration
{
    x <- unlist(x);
    if(na.rm) x <- x[!is.na(x)]
    u <- unique(x);
    n <- length(as.factor(u));
    frequencies <- rep(0, n);
    for(i in 1:n)
    {
        if(is.na(u[i]))
        {
            frequencies[i] <- sum(is.na(x))
        } else
        {
            frequencies[i] <- sum(x==u[i], na.rm=TRUE)
        }
    }
    u[which.max(frequencies)]
}

modalvalueTest <- function()
# tests modalvalue()
#
# NOTE: Should also test with na.rm=TRUE.
{
     checkEquals(7, modalvalue(c(5,5,3,7,2,7,0,7))
                ,"Error: modalvalue of numbers fails"
                )
     checkEquals(7, modalvalue(c(5,5,3,7,2,7,0,7,2,2,NA,NA))
                ,"Error: modalvalue of numbers fails with few values"
                )
     checkTrue(is.na(modalvalue(c(5,5,3,7,2,7,0,7,2,2,NA,NA,NA,NA,NA)))
                ,"Error: modalvalue of numbers fails with many missing values"
                )
     checkTrue(is.na(modalvalue(rep(NA,20)))
              ,"Error: modalvalue of numbers fails with all missing values"
              )
     checkEquals(7, modalvalue(c(5,5,3,7,2,7,0,7,2,2))
                ,"Error: modalvalue of numbers fails with more than one mode"
                )
     checkEquals('c', modalvalue(c(letters[1:6],'c'))
                ,"Error: modalvalue of characters fails"
                )
     checkEquals('b', modalvalue(c(letters[1:6],'c', 'b'))
                ,"Error: modalvalue of characters fails with > 1 mode"
                )

}


dfWiden <- function(df, keys, name, values, makeNumeric=TRUE)
# Converts a data frame from 'narrow' format (variables listed vertically in a 
# single column) to 'wide' format (values listed horizontally with separate
# columns for each variable).  The returned data frame will contain a column
# for each key listed, and have a column for each variable name and given that 
# name.
#
# e.g. 'narrow' format:                'wide' format:
#      key1 key2 variable   value      key1 key2 meanX stX
#      foo  1    meanX      0.7        foo  1    0.7   4.7
#      foo  1    sdX        4.7        foo  2    1.3   NA
#      foo  2    meanX      1.3        bar  1    NA    2.27
#      bar  1    sdX        2.27
#
# ARGUMENTS:
# df           Data frame in 'narrow' format to be converted.
# keys         Vector of column names in df which together uniquely identify
#              a location to which the variables are associated. e.g. 'uid'
#              or c('site_id','year','visit_no').
# name         Name of column with the variable names
# values       Name of column with the variable values.
# makeNumeric  Specify whether to allow columns which are entirely numeric
#              to remain as character type.  If TRUE, these columns will
#              be attempted to convert into type numeric, otherwise no
#              conversion will be attempted.
#
# ASSUMPTIONS:
# A variable occurs no more than once within a combination of variables listed
# in the keys argument.
#
{
  # regexp of a string that isn't a number
  notNumber <- '[a-df-zA-DF-Z _:;=\\/\\|\\?\\*\\(\\)\\$\\^%,<>]'

  # Get list of variable names
  names <- unique(df[,name])

  for (i in 1:length(names)) {
    # Separate input data frame by variable name, convert those values to 
    # numeric if specified, properly name the new column, and finally
    # merge them horizontally.
    tt <- subset(df, get(name)==names[i])[c(keys,values)]
    if (makeNumeric 
       & is.character(tt[,values])
       & length(grep(notNumber,tt[,values])) == 0
       ) {
       tt[,values] <- as.numeric(tt[,values])
    }
    tt <- rename(tt, values, names[i])

    if(i==1) {
      wide <- tt
    } else {
      wide <- merge(wide, tt, by=keys, all=TRUE)
    }

    #cat(paste('.',as.character(i),sep=''))
  }

  return(wide)

}


dfLengthen <- function(df, keys, name, value, values)
# Converts a data frame from 'wide' format (values listed horizontally with 
# separate columns for each variable) to 'narrow' format (variables listed 
# vertically in a single column).  The returned data frame will contain a 
# column containing the names of each variable, and another column containing 
# the values of those variables.
# e.g. 'narrow' format:                'wide' format:
#      key1 key2 variable   value      key1 key2 meanX stX
#      foo  1    meanX      0.7        foo  1    0.7   4.7
#      foo  1    sdX        4.7        foo  2    1.3   NA
#      foo  2    meanX      1.3        bar  1    NA    2.27
#      bar  1    sdX        2.27
#
# ARGUMENTS:
# df         Data frame in 'wide' format to be converted.
# keys       Vector of column names in df which together uniquely identify
#            a location to which the variables are associated. e.g. 'uid'
#            or c('site_id','year','visit_no') or c('key1','key2).
# name       Name of column to contain the variable names, e.g. 'variable'
# value      Name of column to contain the variable values, e.g. 'value'
# values     Vector of column names with values to include in the output
#              e.g. c('meanX', 'stX')
#
# ASSUMPTIONS:
# There is one row for each combination of variables listed in the keys
#   argument.
#
{
  for (i in 1:length(values)) {
    tt <- df[c(keys, values[i])]
    tt <- rename(tt, values[i], value)
    tt[name]<-values[i]

    if(i==1) {
      long <- tt
    } else {
      long <- rbind(long, tt)
    }

    #cat(paste('.',as.character(i),sep=''))
  }

  return(long)
}


normalizedCover <- function(df, coverValue, coverNorm, allowTotalBelow100=FALSE)
# Calculates normalized areal cover values so they total 100% at each
# station/subid.  Returns the input data frame with an additional column
# containing the normalized cover values.
#
#   coverNorm <- coverValue / sum(coverValue at each station)
#
# ARGUMENTS:
# df                 Input data frame containing cover values to be normalized.
#                    This is expected to have the same columns as the data frame
#                    with the NLA phab data, particularly uid, subid and the 
#                    column specified by the coverValue argument.
# coverValue         Name of column in data frame with cover values.
# coverNorm          Name of new column with normalized cover values.
# allowTotalBelow100 Set to TRUE if the set of cover categories being 
#                    normalized do not exhaust all cover possibilities and thus
#                    are allowed to sum to below 100% but not over 100%.  A 
#                    FALSE value will result in values which are always 
#                    normalized to 100%.
#
# ASSUMPTIONS:
# The input data frame contains only those parameters to include in the
#   normalization.
# The input data frame uses columns uid and subid to uniquely identify
#   stations in a site.
# The cover values range from 0-1, inclusive.
# The input data frame does not contain columns named .sumCover, .coverNorm or
#   .nValidValues
#
{
  # calculate total recorded cover at each station and fold it back into
  # the original dataframe
  tt <- aggregate(df[coverValue]
                 ,list('uid'=df$uid, 'subid'=df$subid)
                 ,sum, na.rm=TRUE
                 )
  tt <- rename(tt, coverValue, '.sumCover')

  tt <- merge(df, tt, by=c('uid','subid'), all.x=TRUE)

  # count number of values; will be zero if all NA or NaN, then fold into
  # the dataframe.  Zero counts of data for a class mean we can't
  # normalize data for that class.
  tt2 <- aggregate(df[coverValue]
                 ,list('uid'=df$uid, 'parameter'=df$parameter)
                 ,count
                 )
  tt2 <- rename(tt2, coverValue, '.nValidValues')

  tt <- merge(tt,tt2, by=c('uid','parameter'), all.x=TRUE)

  # Normalize cover.  Calculate normalizing factor, handling special cases:
  #   a) no numeric values (.nValidValues==0, i.e. all NA or NaN)
  #   b) zero total cover (.sumCover==0)
  factor <- ifelse(allowTotalBelow100 & tt$.sumCover <= 1, 1, 1/tt$.sumCover)
  factor[tt$.sumCover==0] <- 0
  factor[tt$.nValidValues==0] <- NA

  tt$.coverNorm <- unlist(tt[coverValue]) * factor

  tt$.sumCover <- NULL
  tt$.nValidValues <- NULL

  tt <- rename(tt, '.coverNorm', coverNorm)

  return(tt)
}

normalizedCoverTest <- function()
# tests normalizedCover()
{
  # Set up parameter values that will be reused in each of the uids of the test
  # data.
  baseData <- data.frame(
    'parameter'= rep(c('cat1', 'cat2', 'cat3', 'cat4', 'cat1NA'
                      ,'catAllNA','cat1NaN','catAllNaN'
                      )
                    ,each=10
                    )
    ,'subid'   = rep(LETTERS[1:10], times=8)
    ,'cover'   = c(0.0, 0.5, 0.5, 0.0, 1.0, 0.3, 0.0, 0.5, 0.4, 0.7
                  ,0.3, 0.4, 0.7, 0.7, 0.9, 0.0, 0.1, 0.5, 0.4, 0.4
                  ,0.7, 0.8, 0.3, 0.4, 0.0, 0.2, 0.3, 0.0, 0.2, 0.3
                  ,0.0, 1.0, 0.0, 0.5, 0.9, 0.1, 0.4, 0.2, 0.3, 0.5
                  ,0.0, 0.5, 0.5, 0.0, 1.0, 0.3, 0.0, 0.5, 0.4, NA
                  ,NA , NA , NA , NA , NA , NA , NA , NA , NA , NA 
                  ,0.0, 0.5, 0.5, 0.0, 1.0, 0.3, 0.0, 0.5, 0.4, NaN
                  ,NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN
                  )
  )
  
  # Test integrity of base data before formal function tests by checking cover
  # means by parameter and subid to see if they've been changed without
  # adjusting the test.  Determine expected means here, and compare them to the
  # calculated means.
  # Note that while mean(NA) is NA, but mean(NA, na.rm=TRUE) is NaN.
  parameterMeans <- data.frame(
     parameter=c('cat1', 'cat2', 'cat3', 'cat4', 'cat1NA'
                ,'catAllNA','cat1NaN','catAllNaN'
                )
    ,expected=c(0.39, 0.44, 0.32, 0.39, 0.35555556
               ,NaN, 0.35555556, NaN
               )
  )
  subidMeans <- data.frame(
     subid=c(LETTERS[1:10])
    ,expected=c(0.166666667, 0.616666667, 0.416666667, 0.266666667
               , 0.8, 0.2, 0.133333333, 0.366666667, 0.35, 0.475
               )
  )

  tt1 <- aggregate(baseData$cover, list('parameter'=baseData$parameter)
                  ,mean, na.rm=TRUE
                  )
  tt2 <- aggregate(baseData$cover, list('subid'=baseData$subid)
                  ,mean, na.rm=TRUE
                  )

  # Compare expected and actual means.
  testParam<-NULL

  tt<-subset(merge(tt1,parameterMeans, by=c('parameter'))
            ,abs(x-expected)> 10^-8      | 
             is.na(x)!=is.na(expected)   | 
             is.nan(x)!=is.nan(expected)
            )
  checkEquals(0, nrow(tt)
             ,paste("Error: normalizedCoverTest baseData has unexpected parameter means:"
                   ,paste(tt$parameter
                         ,paste(' calc:',tt$x, sep='')
                         ,paste(' expected:',tt$expected, sep='')
                         ,collapse='; '
                         )
                   ,sep=' '
                   )
             )
   checkEquals(0, nrow(tt)
              ,paste("Error: normalizedCoverTest baseData has unexpected subid means:"
                    ,paste(tt$subid
                          ,paste('calc:',tt$x, sep='')
                          ,paste('expected:',tt$expected, sep='')
                          ,collapse='; '
                          )
                    ,sep=' '
                    )
              )


  # Build the test dataframe from baseData, first 1 parameter per uid, then
  # 4 parameters per UID.
  dfTest1  <- baseData[baseData$parameter %in% c('cat1'),]
  dfTest1$uid='test1'
  dfTest1b <- baseData[baseData$parameter %in% c('cat1NA'),]
  dfTest1b$uid='test1b'
  dfTest1c <- baseData[baseData$parameter %in% c('cat1NaN'),]
  dfTest1c$uid='test1c'
  dfTest1d <- baseData[baseData$parameter %in% c('catAllNA'),]
  dfTest1d$uid='test1d'
  dfTest1e <- baseData[baseData$parameter %in% c('catAllNaN'),]
  dfTest1e$uid='test1e'

  dfTest4  <- baseData[baseData$parameter %in% c('cat1','cat2','cat3','cat4'),]
  dfTest4$uid='test4'
  dfTest4b <- baseData[baseData$parameter %in% 
                       c('cat1','cat2','cat3','cat1NA'),]
  dfTest4b$uid='test4b'
  dfTest4c <- baseData[baseData$parameter %in% 
                       c('cat1','cat2','cat3','cat1NaN'),]
  dfTest4c$uid='test4c'
  dfTest4d <- baseData[baseData$parameter %in% 
                       c('cat1','cat2','cat3','catAllNA'),]
  dfTest4d$uid='test4d'
  dfTest4e <- baseData[baseData$parameter %in% 
                       c('cat1','cat2','cat3','catAllNaN'),]
  dfTest4e$uid='test4e'
  dfTest4f <- baseData[baseData$parameter %in% 
                       c('cat1','cat1NA','cat3','cat1NaN'),]
  dfTest4f$uid='test4f'

  dfTest<-rbind(dfTest1, dfTest1b, dfTest1c, dfTest1d, dfTest1e
               ,dfTest4, dfTest4b, dfTest4c, dfTest4d, dfTest4e, dfTest4f
               )


  # Build the expected results data frames separately for the case where the 
  # cover  categories are complete (i.e. must sum to 100% at a station) and 
  # the case where the cover categories are incomplete (i.e. must sum to 100% 
  # or less).  Expected results are for means of test data, with na.rm=TRUE.
  expectedCompleteResults <- as.data.frame(rbind(
       c('uid'='test1', 'parameter'='cat1', 'expected'=0.7)
      ,c('test1b', 'cat1NA', 6/9)
      ,c('test1c', 'cat1NaN', 6/9)
      ,c('test1d', 'catAllNA', NaN)       # mean(NA * 1/sum(NA)) isn't a number
      ,c('test1e', 'catAllNaN', NaN)      # mean(NaN * 1/sum(NA)) isn't a number

      ,c('test4',  'cat1', 0.24684414)
      ,c('test4',  'cat2', 0.27336287)
      ,c('test4',  'cat3', 0.24663705)
      ,c('test4',  'cat4', 0.23315594)

      ,c('test4b', 'cat1', 0.23161479)
      ,c('test4b', 'cat2', 0.29332886)
      ,c('test4b', 'cat3', 0.29344156)
      ,c('test4b', 'cat1NA', 0.20179421)

      ,c('test4c', 'cat1', 0.23161479)
      ,c('test4c', 'cat2', 0.29332886)
      ,c('test4c', 'cat3', 0.29344156)
      ,c('test4c', 'cat1NaN', 0.20179421)

      ,c('test4d', 'cat1', 0.31537668)
      ,c('test4d', 'cat2', 0.35477229)
      ,c('test4d', 'cat3', 0.32985103)
      ,c('test4d', 'catAllNA', NaN)       # mean(NA * 1/sum(x)) isn't a number
                                          # when na.rm=TRUE
      ,c('test4e', 'cat1', 0.31537668)
      ,c('test4e', 'cat2', 0.35477229)
      ,c('test4e', 'cat3', 0.32985103)
      ,c('test4e', 'catAllNaN', NaN)      # mean(NaN * 1/sum(x)) isn't a number
                                          # when na.rm=TRUE
      ,c('test4f', 'cat1', 0.24202773)
      ,c('test4f', 'cat1NA', 0.19114192)
      ,c('test4f', 'cat3', 0.41391681)
      ,c('test4f', 'cat1NaN', 0.19114192)

    )
    ,stringsAsFactors=FALSE
  )
  expectedCompleteResults$expected <- 
    as.numeric(expectedCompleteResults$expected)

  expectedIncompleteResults <- as.data.frame(rbind(
       c('uid'='test1', 'parameter'='cat1', 'expected'=0.39)
      ,c('test1b', 'cat1NA', 0.3555555556)
      ,c('test1c', 'cat1NaN', 0.3555555556)
      ,c('test1d', 'catAllNA', NaN)       # mean(NA * 1/sum(NA)) isn't a number
      ,c('test1e', 'catAllNaN', NaN)      # mean(NaN * 1/sum(NA)) isn't a number

      ,c('test4',  'cat1', 0.22684414)
      ,c('test4',  'cat2', 0.27086287)
      ,c('test4',  'cat3', 0.22580372)
      ,c('test4',  'cat4', 0.21648927)

      ,c('test4b', 'cat1', 0.22411479)
      ,c('test4b', 'cat2', 0.27832886)
      ,c('test4b', 'cat3', 0.24344156)
      ,c('test4b', 'cat1NA', 0.19346088)

      ,c('test4c', 'cat1', 0.22411479)
      ,c('test4c', 'cat2', 0.27832886)
      ,c('test4c', 'cat3', 0.24344156)
      ,c('test4c', 'cat1NaN', 0.19346088)

      ,c('test4d', 'cat1', 0.28537668)
      ,c('test4d', 'cat2', 0.33977229)
      ,c('test4d', 'cat3', 0.26485103)
      ,c('test4d', 'catAllNA', NaN)       # mean(NA * 1/sum(x)) isn't a number
                                          # when na.rm=TRUE
      ,c('test4e', 'cat1', 0.28537668)
      ,c('test4e', 'cat2', 0.33977229)
      ,c('test4e', 'cat3', 0.26485103)
      ,c('test4e', 'catAllNaN', NaN)      # mean(NaN * 1/sum(x)) isn't a number
                                          # when na.rm=TRUE
      ,c('test4f', 'cat1', 0.24202773)
      ,c('test4f', 'cat1NA', 0.19114192)
      ,c('test4f', 'cat3', 0.25391681)
      ,c('test4f', 'cat1NaN', 0.19114192)
    )
    ,stringsAsFactors=FALSE
  )
  expectedIncompleteResults$expected <- 
    as.numeric(expectedIncompleteResults$expected)


  # Make the normalization calculations
  tt <- normalizedCover(dfTest, 'cover', 'normCover')
  testResultsComplete <- aggregate(tt$normCover
                                  ,list('uid'=tt$uid, 'parameter'=tt$parameter)
                                  ,mean, na.rm=TRUE
                                  )

  tt <- normalizedCover(dfTest, 'cover', 'normCover', allowTotalBelow100=TRUE)
  testResultsIncomplete <- aggregate(tt$normCover
                                    ,list('uid'=tt$uid
                                         ,'parameter'=tt$parameter
                                         )
                                    ,mean, na.rm=TRUE
                                    )

  # Merge calculations and expected values for the test and accumulate detected
  # errors for both normalization types.
  tt<-subset(merge(expectedCompleteResults, testResultsComplete
                  ,by=c('uid','parameter')
                  ,all=TRUE
                  )
            ,abs(x-expected)> 10^-8      | 
             is.na(x)!=is.na(expected)   | 
             is.nan(x)!=is.nan(expected)
            )

  if(nrow(tt)>0) {
    testErrors <- rbind(testParam
                       ,paste('normalizedCover is incorrect for complete data'
                             ,tt$parameter
                             ,paste('calc:',tt$x, sep='')
                             ,paste('expected:',tt$expected, sep='')
                             )
                       )
  }

  tt<-subset(merge(expectedIncompleteResults, testResultsIncomplete
                  ,by=c('uid','parameter')
                  ,all=TRUE
                  )
            ,abs(x-expected)> 10^-8      | 
             is.na(x)!=is.na(expected)   | 
             is.nan(x)!=is.nan(expected)
            )

  checkEquals(0, nrow(tt)
             ,"Error: normalizedCover is incorrect for incomplete cover data"
             )
#    testErrors <- rbind(testParam
#                       ,paste('Normalization results differ for '
#                             ,tt$parameter
#                             ,paste('calc:',tt$x, sep='')
#                             ,paste('expected:',tt$expected, sep='')
#                             )
#                       )


#  # Notify user of any problems in normalization calculations
#  if(! is.null(testParam)) {
#      for(i in 1:dim(testParam)[1]) {
#          funcTestOutput(TRUE, verbose, testParam[i,])
#      }
#  }

}


rename <- function (df, old, new) 
{
  # This method assumes that names in old & new are listed in the same
  # order as the names in df 
  # names(df)[names(df) %in% old] <- new
  if(length(old) != length(new)) {
      print("ERROR: rename() used with different lengths for old and new names")
      return(NULL)
  }

  for(i in 1:length(old)) {
      names(df)[names(df)==old[i]] <- new[i]
  }

  return(df)
}

renameTest <- function(verbose=FALSE)
{   
    dfTest<-data.frame(idx1=c('one','two','two','three')
                      ,idx2=c(1,1,2,3)
                      ,coverA=c(1, 1, 1 ,NA)
                      ,coverB=c(2, 2, 2 ,NA)
                      ,coverC=c(1, 1, NA,NA)
                      ,coverD=c(3, 3, 3 ,NA)
                      ,coverE=c(2, 2, NA,NA)
                      ,coverF=c(0, 3, 3 ,NA)
                      ,coverG=c(2, 2, 2 ,NA)
                      ,coverH=c(0, 2, 3 ,NA)
                      )

    rr<-rename(dfTest
              ,c('coverA','coverB','coverC','coverD'
                ,'coverE','coverF','coverG','coverH'
                )
              ,LETTERS[1:8]
              )
    checkEquals(c('idx1','idx2',LETTERS[1:8]), names(rr)
               ,"Error: rename failed basic renaming"
               )

    rr<-rename(dfTest
              ,c('coverA','coverC','coverE','coverG'
                ,'coverB','coverD','coverF','coverH'
                )
              ,c('A','C','E','G','B','D','F','H')
              )
    checkEquals(c('idx1','idx2',LETTERS[1:8]), names(rr)
               ,"Error: rename failed out-of-order renaming"
               )

}


trimws <- function(text)
# Trims leading and trailing white space from a character string.
# Taken from http://togaware.com/datamining/survivor/Trim_Whitespace.html
#
# ARGUMENTS:
# text     character string from which leading and trailing white space
#            will be removed
#
{
    gsub("^[[:blank:]]*", "", gsub("[[:blank:]]*$", "", text))
}


uidCreate <- function(df, keys, sep='+')
# Returns a vector consisting of a single unique identifier for the specified 
# dataframe using the specified list of keys.  This is done to replace multiple
# keys with a single one prior to metrics computation.
#
# Arguments:
# df       The data frame for which the unique identifiers will be developed.
# keys     A list of names in the dataframe which combine to uniquely specify
#            a location for which metrics will be calculated.
# sep      A character string used to distinguish between segments of the
#             individual keys in the uid.
# 
{

  for(k in 1:length(keys)) {
      if(k==1) {
          uniqueID<-df[,keys[k]]
      } else {
          uniqueID<-paste(uniqueID, df[,keys[k]], sep=sep)
      }
  }

  return(uniqueID)
}


uidSeparate <- function(df, uidName, keyNames, sep='+')
# Returns the dataframe consisting of the initial dataframe with additional
# columns containing the components of the uid.  This function reverses the
# operation of uidCreate().
#
# ARGUMENTS:
# df        The data frame for which separate keys will be created from the
#             single variable named in 'uidName'
# uidName   A character string naming the variable containing the unique
#             identifier for each site visit.
# keyNames  A character vector containing the names of columns to be created
#             in the dataframe and containing portions of the uid values.
# sep       A character string used to distinguish between segments of the
#             individual keys in the uid.
#
{

  for (r in 1:length(df[,1])) {
      # for each row in the input dataframe, parse the uid and put the
      # individual parts in the specified variables.  The use of as.character
      # converts the uidName column from a factor if it needs to be.
      keyParts<- unlist(strsplit(as.character(df[r,uidName]), sep, fixed=TRUE))
      for (k in 1:length(keyNames)) {
          df[r,keyNames[k]] <- keyParts[k]
      }
  }

  return(df)

}


uidCreateSeparateTest <- function(verbose=FALSE) 
# Tests uidCreate() and uidSeparate() in tandem.
{
  df0 <- expand.grid(k1=1:10
                    ,k2=c('a','b','c','d')
                    ,k3=1:3
                    ,k4=c('foo','bar','baz','gnip','gnop')
                    )
  df0 <- data.frame(df0, stringsAsFactors=FALSE)
  df0$k2 <- as.character(df0$k2)
  df0$k4 <- as.character(df0$k4)
  df0$x<-row(df0[1])
  df0$y<-runif(length(df0[,1]), 0, 1)
  
  # make a uid and parse it.
  df1<-df0
  df1$uid <- uidCreate(df1, c('k1','k2','k3','k4'))
  df1 <- uidSeparate(df1, 'uid', c('t1','t2','t3','t4'))
  df1$t1 <- as.integer(df1$t1)
  df1$t3 <- as.integer(df1$t3)

  # check the key values and their orders.
  checkTrue(all(df1$k1==df1$t1 & df1$k2==df1$t2 & df1$k3==df1$t3 & df1$k4==df1$t4)
           ,"Error: uidCreate/uidSeparate failed to maintain key values"
           )

  # check data associated with keys
  df2<-df1[,c('t1','t2','t3','t4','x','y')]
  df2<-rename(df2, c('t1','t2','t3','t4'), c('k1','k2','k3','k4'))
  checkTrue(identical(df0,df2)
           ,"Error: uidCreate/uidSeparate failed to maintain data values"
           )


  # try test again with odd separator in uid
  df1<-df0
  df1$uid <- uidCreate(df1, c('k1','k2','k3','k4'), sep='%\\^')
  df1 <- uidSeparate(df1, 'uid', c('t1','t2','t3','t4'), sep='%\\^')
  df1$t1 <- as.integer(df1$t1)
  df1$t3 <- as.integer(df1$t3)

  # check the key values and their orders.
  checkTrue(all(df1$k1==df1$t1 & df1$k2==df1$t2 & df1$k3==df1$t3 & df1$k4==df1$t4)
           ,"Error: uidCreate/uidSeparate failed to maintain key values with odd separator"
           )

  # check data associated with keys
  df2<-df1[,c('t1','t2','t3','t4','x','y')]
  df2<-rename(df2, c('t1','t2','t3','t4'), c('k1','k2','k3','k4'))
  checkTrue(identical(df0,df2)
           ,"Error: uidCreate/uidSeparate failed to maintain data values with odd separator"
           )

}


# end of file