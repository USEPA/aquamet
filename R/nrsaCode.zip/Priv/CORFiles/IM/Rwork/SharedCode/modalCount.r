# modalCount.r
#
# 03/10/10 cws created
#
require(RUnit)

modalCount <- function(x)
# Returns the number of occurences as an integer of the most common (mode)
# element in x.
{
  v <- modalvalue(x)
  n <- sum(x==v)

  return(n)
}

modalCountTest <- function()
# tests modalCount()
{

  checkEquals(3L, modalCount(c(LETTERS,LETTERS, 'X'))
             ,'Error: modalCount broken for letters with single mode'
             )
  checkEquals(2L, modalCount(c(LETTERS,LETTERS))
             ,'Error: modalCount broken for letters with multiple modes'
             )

  checkEquals(3L, modalCount(c(1:10, 1:10, 4))
             ,'Error: modalCount broken for numbers with clear mode'
             )
  checkEquals(2L, modalCount(c(1:10, 1:10))
             ,'Error: modalCount broken for numbers with multiple modes'
             )

  checkEquals(3L, modalCount(data.frame(ff=c(LETTERS,LETTERS, 'X'))$ff)
             ,'Error: modalCount broken for factors with single mode'
             )
  checkEquals(2L, modalCount(data.frame(ff=c(LETTERS,LETTERS))$ff)
             ,'Error: modalCount broken for factors with multiple modes'
             )
}

# end of file