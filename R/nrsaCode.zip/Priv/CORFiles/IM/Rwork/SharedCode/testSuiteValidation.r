# testSuiteValidation.r
#
# Defines and runs the test suite for the table validation functions
#
# 09/22/09 cws Created.  Currently only checks underlying stVal* functions.
# 12/15/11 cws Added validation*, formerly only did structure validation functions.
#

require(RUnit)

testSuiteValidation <- function()
# Define and run the test suite for the db*() functions
#
# Results are saved to timestamped HTML file
{
  testSuite <- defineTestSuite('Validation'
                              ,dirs='l:/Priv/CORFiles/IM/Rwork/SharedCode'
                              ,testFileRegexp="^(stVal|validation|combineValidationResult).+\\.r$"
                              ,testFuncRegexp="^.+Test$"
                              )

  testResult <- runTestSuite(testSuite)

  testResultFile <- 'l:/Priv/CORFiles/IM/Rwork/SharedCode/testResults_validation.html'
  printHTMLProtocol(testResult, fileName=testResultFile)

}
