# char2ASCII.r
# Converts a vector of characters to integer codes (defaulting to ASCII
# character codes).  Returns a vector of converted integer codes the same length
# as the input vector.  Where an element of the input is not found in the
# lookup vector, the output vector element is NA.
#
#  1-26-2011 cws Created
#

char2ASCII <- function(v, lookup=NULL)
#
# ARGUMENTS:
# v         vector of character codes to convert to numeric codes
# lookup    vector of possible characters, the corresponding code for each being
#             the index of each element.  Defaults to standard 8 bit ASCII
#             encoding.
{
  if(is.null(lookup)) {
      lookup <- unlist(strsplit(rawToChar(as.raw(1:255)), ''))
  }

  codeList <- apply(as.matrix(v, ncol=1), 1, function(x) { which(lookup==x) } )

  if(length(codeList)==0) {
      # Handle special case where no elements of v occur in lookup.
      codes <- rep(NA, length(v))
  } else {
      codes <- unlist(lapply(codeList
                            ,function(x) {
                                 ifelse(length(x)==0, NA, unlist(x))
                             }
                            )
                     )
  }

  return(codes)
}


char2ASCIITest <- function()
# Unit test for char2ASCII()
{
  rr <- char2ASCII(c(LETTERS,LETTERS,LETTERS,letters))
  ee <- c(rep(65:90, 3), 97:122)
  checkIdentical(ee, rr
                ,"Error: did not correctly convert LETTERS to ASCII"
                )

  rr <- char2ASCII(c(LETTERS,LETTERS,LETTERS), LETTERS)
  ee <- rep(1:26, 3)
  checkIdentical(ee, rr
                ,"Error: did not correctly convert LETTERS to indices"
                )

  rr <- char2ASCII(c(LETTERS,'XX',letters))
  ee <- c(65:90, NA, 97:122)
  checkIdentical(ee, rr
                ,"Error: did not correctly convert misc. to ASCII"
                )

  rr <- char2ASCII(c(LETTERS,'XX',letters), LETTERS)
  ee <- c(1:26, rep(NA, 27))
  checkIdentical(ee, rr
                ,"Error: did not correctly convert misc. to indices"
                )

  rr <- char2ASCII(c(LETTERS[1:11], paste('X', LETTERS[1:11], sep='')), LETTERS[1:11])
  ee <- c(1:11, rep(NA,11))
  checkIdentical(ee, rr
                ,"Error: did not correctly convert transect values. to indices"
                )

  rr <- char2ASCII(paste('X', LETTERS[1:11], sep=''), LETTERS[1:11])
  ee <- rep(NA,11)
  checkIdentical(ee, rr
                ,"Error: did not correctly handle case where input does not occur in lookup vector"
                )

}

# end of file