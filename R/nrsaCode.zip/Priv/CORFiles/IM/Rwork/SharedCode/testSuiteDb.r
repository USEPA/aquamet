# testSuiteDb.r
#
# Defines and runs the test suite for the database change tracking functions
#
# 07/06/09 cws Created
# 07/10/09 cws Changed testFileRegexp to eliminate temporary development files.
# 09/22/09 cws Changed file paths from changeTracking/ to SharedCode/ to reflect
#              current location of source code.
#

require(RUnit)

testSuiteDb <- function()
# Define and run the test suite for the db*() functions
#
# Results are saved to timestamped HTML file
{
  testSuite <- defineTestSuite('db*'
                              ,dirs='l:/Priv/CORFiles/IM/Rwork/SharedCode'
                              ,testFileRegexp="^db.*\\.r$"
                              ,testFuncRegexp="^.+Test$"
                              )

  testResult <- runTestSuite(testSuite)

  testResultFile <- 'l:/Priv/CORFiles/IM/Rwork/SharedCode/testResults_db.html'
  printHTMLProtocol(testResult, fileName=testResultFile)

}
