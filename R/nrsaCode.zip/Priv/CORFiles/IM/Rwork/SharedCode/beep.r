# beep.r
#
# Plays a tone on the PC.  Currently sends a .wav file through the sound card.
# Useful for alerting user when a long command has finished.
#
# 01/18-2011 cws created.
#

beep <- function()
# beeps at the user.
{
  require(tuneR)
  
  waveType<-square
  stepTime<-0.1
  bits<-16
  Wobj <- bind((waveType(131, bit=bits, stepTime, xunit='time') + waveType(165, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(130, bit=bits, stepTime, xunit='time') + waveType(168, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(129, bit=bits, stepTime, xunit='time') + waveType(172, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(128, bit=bits, stepTime, xunit='time') + waveType(176, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(127, bit=bits, stepTime, xunit='time') + waveType(180, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(126, bit=bits, stepTime, xunit='time') + waveType(184, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(125, bit=bits, stepTime, xunit='time') + waveType(188, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(124, bit=bits, stepTime, xunit='time') + waveType(192, bit=bits, stepTime, xunit='time')) / 2
              ,(waveType(123, bit=bits, stepTime, xunit='time') + waveType(196, bit=bits, stepTime, xunit='time')) / 2
              )
  play(Wobj, 'c:/WINDOWS/system32/mplay32', '/play /close')

}

# end of file