# dfToR.r
#
# Converts a dataframe to the R code necessary to create it.  This should eventually go in the SharedCode/ folder.
#
# 06-28-10 cws created
# 12-06-11 cws Added comments. Adding carriage returns to wrap definitions of
#          each column, inserting a /n after every 5 values.
# 12-21-11 cws Separating code handling conversion of columns to function vecToR().
#

dfToR <- function(df)
# Convert a dataframe to R code that will create it when run.  There are a
# variety of other ways to do this, such as reading in a textConnection() and
# rbind()ing a series of calls to data.frame(), one per row.  The first
# alternative gets really wide when the input dataframe has a lot of columns,
# which won't print well.  The other alternative gets really loooong when the
# dataframe has lots of rows.  Creating the dataframe using a single call to
# data.frame() takes the middle ground as being 'foldable' so it doesn't need
# to get too wide, and won't take for ever to execute like rbind()ing thousands
# of rows would.
#
# NOTE: write results to a file like this, and then copy/paste the contents
# of that file into the R program or other document.
#
# Returns a character string of R code.
#
# Arguments:
# df        dataframe to convert to R code.
#
{
  dfCode <- "data.frame("
  for(colName in names(df)) {
      vecCode <- vecToR(df[[colName]], indentSpaces=nchar(colName)+5)
      
      # create string defining the column and append it to earlier strings.
      if(colName != names(df)[1]) dfCode <- paste(dfCode, ',', sep='')
      dfCode <- paste(dfCode
                     ,sprintf("%s = %s\n", colName, vecCode)
                     ,sep=''
                     )
      
  }

  dfCode <- paste(dfCode, ",stringsAsFactors=FALSE\n)", sep='')
  return(dfCode)

}


dfToRDEPRECATED <- function(df)
# Convert a dataframe to R code that will create it when run.  There are a
# variety of other ways to do this, such as reading in a textConnection() and
# rbind()ing a series of calls to data.frame(), one per row.  The first
# alternative gets really wide when the input dataframe has a lot of columns,
# which won't print well.  The other alternative gets really loooong when the
# dataframe has lots of rows.  Creating the dataframe using a single call to
# data.frame() takes the middle ground as being 'foldable' so it doesn't need
# to get too wide, and won't take for ever to execute like rbind()ing thousands
# of rows would.
#
# NOTE: write results to a file like this, and then copy/paste the contents
# of that file into the R program or other document.
#
# Returns a character string of R code.
#
# Arguments:
# df        dataframe to convert to R code.
#
{
  dfCode <- "data.frame("
  for(colName in names(df)) {
      colClass <- class(df[[colName]])
      if(colClass[1] == "POSIXt") colClass <- colClass[2]

      if (colClass == 'character')                     colFunc <- 'as.character'
      else if(colClass == 'POSIXct')                   colFunc <- 'as.POSIXct'
      else if(colClass == 'integer')                   colFunc <- 'as.integer'
      else if(colClass == 'numeric')                   colFunc <- 'as.numeric'
      else                                             colFunc <- 'as.ohcrap'

      # create string of a comma separated list of values for each column in 
      # the dataframe. Wrap the lines every 5 values for easier reading.
      if (colClass[1] %in% c('integer','numeric')) {
          #colValues <- paste(df[[colName]], collapse=', ')
          indent <- paste(rep(' ', times=nchar(colName)+5), collapse='')
          colValues <- gsub("([^,]*,[^,]*,[^,]*,[^,]*,[^,]*),"
                           ,paste('\\1\n', indent, ',', collapse='')
                           ,paste(df[[colName]], collapse=', ')
                           )         
      } else {
          # To avoid breaking a line inside a string containing commas, 
          # separate entries by an unlikely value (\x03 = ^C) when wrapping the 
          # lines, and then substitute commas for those odd values.
          #colValues <- paste("'", paste(df[[colName]], collapse="', '"), "'", sep='')
          indent <- paste(rep(' ', times=nchar(colName)+5), collapse='')
          colValues <- gsub('\x03', ','
                           ,gsub("([^\x03]*\x03[^\x03]*\x03[^\x03]*\x03[^\x03]*\x03[^\x03]*)\x03"
                                ,paste('\\1\n', indent, ',', collapse='')
                                ,paste("'", paste(df[[colName]], collapse="'\x03'"), "'", sep='')
                                )
                           )
      }
      
      # create string defining the column and append it to earlier strings.
      if(colName != names(df)[1]) dfCode <- paste(dfCode, ',', sep='')
      dfCode <- paste(dfCode
                     ,sprintf("%s = %s(c(%s))\n", colName, colFunc, colValues)
                     ,sep=''
                     )
      
  }

  dfCode <- paste(dfCode, ",stringsAsFactors=FALSE\n)", sep='')
  return(dfCode)

}

# end of file.