# prepareDataForSAS.r
#
# 06/15/10 cws Created
#
require(RUnit)

prepareDataForSAS <- function (df)
# Filter incomputable values in a way that does not give the SAS import wizard
# conniptions. Inf, -Inf and NaN values are changed to missing (NA).  Date
# values are changed to strings.
# NOTE: the call to the format() function from within the for() loop generates
# an error in prettyNum stating "invalid 'trim' argument".  It is moved out of
# the loop for this reason.
#
{

  for(c in names(df)) {
      if(c=='DATE_COL') {
          df[c] <- format(df[[c]], '%m%d%Y')
      } else {
          df[c] <- ifelse(unlist(df[c]) %in% c(Inf,-Inf), NA, unlist(df[c]))
          df[c] <- ifelse(is.nan(unlist(df[c])), NA, unlist(df[c]))
      }
  }


  return(df)
}


prepareDataForSASTest <- function()
# Unit test for prepareDataForSAS()
{
  # Case: no special values, so no need to change anything
  test <- data.frame(a=rep(1:10,3), b=rnorm(10), stringsAsFactors=FALSE)
  rr <- prepareDataForSAS(test)
  checkEquals(test, rr
             ,"Error: dataframe modified unexpectedly"
             )

  # Case: dataframe contains NA values, no need to change anything
  test <- data.frame(a=rep(1:10,3), b=rnorm(10), stringsAsFactors=FALSE)
  test[c(2,3,7),]$b <- NA
  rr <- prepareDataForSAS(test)
  checkEquals(test, rr
             ,"Error: dataframe with NAs incorrectly modified"
             )

  # Case: dataframe contains NaN values
  test <- data.frame(a=rep(1:10,3), b=rnorm(10), stringsAsFactors=FALSE)
  test[c(2,3,7),]$b <- NaN
  rr <- prepareDataForSAS(test)
  ee <- test
  ee[c(2,3,7),]$b <- NA
  checkEquals(ee, rr
             ,"Error: dataframe with NAs incorrectly modified"
             )

  # Case: dataframe contains Inf values
  test <- data.frame(a=rep(1:10,3), b=rnorm(10), stringsAsFactors=FALSE)
  test[c(2,3,7),]$b <- Inf
  rr <- prepareDataForSAS(test)
  ee <- test
  ee[c(2,3,7),]$b <- NA
  checkEquals(ee, rr
             ,"Error: dataframe with Inf incorrectly modified"
             )

  # Case: dataframe contains -Inf values
  test <- data.frame(a=rep(1:10,3), b=rnorm(10), stringsAsFactors=FALSE)
  test[c(2,3,7),]$b <- -Inf
  rr <- prepareDataForSAS(test)
  ee <- test
  ee[c(2,3,7),]$b <- NA
  checkEquals(ee, rr
             ,"Error: dataframe with -Inf incorrectly modified"
             )

  # Case: dataframe contains DATE_COL column
  test <- data.frame(a=rep(1:10,3)
                    ,DATE_COL=as.POSIXct('2008-01-05')
                    ,stringsAsFactors=FALSE)
  rr <- prepareDataForSAS(test)
  ee <- test
  ee$DATE_COL <- "01052008"
  checkEquals(ee, rr
             ,"Error: dataframe with DATE_COL incorrectly modified"
             )

}

# end of file