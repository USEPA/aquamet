# db.r
#
# Sources functions used to access the database
#
# 10/01/09 cws Created
# 10/06/10 cws Added source() of dbIntegrationTest.r
# 05/06/11 cws Added source() of dbHistoryFetch.r and dbHistoryWrite.r
# 10/14/11 cws Added source() of dbTableKeys.r
# 11/02/11 cws Added source() of dbStudyDB.r

source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbAdd.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbDelete.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbFetch.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbHistoryFetch.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbHistoryWrite.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbInsert.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbIntegrationTest.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbStudyDB.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbTableKeys.r')
source('l:/Priv/CORFiles/IM/Rwork/SharedCode/dbUpdate.r')

# end of file


